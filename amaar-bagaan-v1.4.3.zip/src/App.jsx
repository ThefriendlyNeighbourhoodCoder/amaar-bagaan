import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Leaf,
  Sprout,
  Smartphone,
  Map,
  CalendarDays,
  Settings,
  Home,
  Plus,
  Search,
  Droplets,
  Sparkles,
  LogOut,
  CloudSun,
  ShieldCheck,
  AlertTriangle,
  Download,
  Upload,
  RefreshCcw,
  Trash2,
  Edit3,
  CheckCircle2,
  Flower2,
  ThermometerSun,
  Wind,
  RotateCcw,
  Database,
  ArchiveRestore,
  X,
  Clock3,
  FileText,
  MapPin,
  Navigation,
  Compass,
  LockKeyhole,
  Globe2,
  Heart
} from 'lucide-react';
import { listenToAuth, signInWithGoogle, logout, hasFirebaseConfig, allowedEmails } from './services/firebaseClient.js';
import { loadGardenState, seedFirebaseIfEmpty, savePlant, saveZone, deleteZone, deletePlant, restorePlant, recordCareAction, updateSettings, migrateAndPersistState, reseedMissingData, resetToSeedData, importGardenBackup } from './services/gardenRepository.js';
import { fetchWeather, getFallbackWeather } from './services/weatherService.js';
import { enrichPlantByName } from './services/plantKnowledgeService.js';
import { buildCareTasks, buildWeatherAdvice, gardenSummary, zoneRisk } from './services/careEngine.js';
import { addDays, formatFriendlyDate, formatShortDate, formatTime } from './utils/dateUtils.js';
import { makeId } from './utils/idUtils.js';

const tabs = [
  { id: 'plants', label: 'Plants', icon: Leaf },
  { id: 'map', label: 'Map', icon: Map },
  { id: 'home', label: 'Home', icon: Home },
  { id: 'care', label: 'Care', icon: CalendarDays },
  { id: 'settings', label: 'Settings', icon: Settings }
];

const emptyPlant = {
  name: '',
  localName: '',
  scientificName: '',
  category: 'General Plant',
  zoneId: 'roof-east',
  indoorOutdoor: 'outdoor',
  sunlight: 'partial-sun',
  waterNeed: 'moderate',
  waterFrequencyDays: 3,
  fertilizerFrequencyDays: 45,
  soilType: 'Well-drained potting soil',
  imageUrl: '',
  imageSource: 'Manual',
  summary: '',
  careDos: ['Check soil before watering', 'Remove dry leaves'],
  careDonts: ['Avoid overwatering'],
  lastWateredAt: null,
  lastFertilizedAt: null,
  verifiedByUser: true,
  sourceGenerated: false
};

function classNames(...values) {
  return values.filter(Boolean).join(' ');
}

function useGardenApp() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [state, setState] = useState(null);
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = listenToAuth((nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!authReady) return;

    if (hasFirebaseConfig && !user) {
      setState(null);
      setLoading(false);
      return;
    }

    if (user && user.allowed === false) {
      setState(null);
      setLoading(false);
      return;
    }

    let cancelled = false;

    async function boot() {
      setLoading(true);
      try {
        if (hasFirebaseConfig) await seedFirebaseIfEmpty();
        const gardenState = await loadGardenState();
        if (!cancelled) setState(gardenState);
      } catch (error) {
        console.error("Amaar Bagaan boot failed. Falling back to local cached state.", error);
        const fallbackState = await loadGardenState();
        if (!cancelled) setState(fallbackState);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    boot();
    return () => {
      cancelled = true;
    };
  }, [authReady, user]);

  useEffect(() => {
    if (!state?.settings) return;
    let cancelled = false;
    async function loadWeather() {
      try {
        const data = await fetchWeather(state.settings);
        if (!cancelled) setWeather(data);
      } catch (error) {
        console.warn(error);
        if (!cancelled) setWeather(getFallbackWeather());
      }
    }
    loadWeather();
    return () => {
      cancelled = true;
    };
  }, [state?.settings?.latitude, state?.settings?.longitude]);

  return { user, authReady, state, setState, weather, setWeather, loading };
}

export default function App() {
  const { user, authReady, state, setState, weather, loading } = useGardenApp();
  const [activeTab, setActiveTab] = useState('home');
  const [selectedPlant, setSelectedPlant] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [editingPlant, setEditingPlant] = useState(null);
  const [showSmartAdd, setShowSmartAdd] = useState(false);
  const [showZoneEditor, setShowZoneEditor] = useState(false);
  const [toast, setToast] = useState('');
  const [lastDeletedPlant, setLastDeletedPlant] = useState(null);

  const tasks = useMemo(() => (state ? buildCareTasks(state.plants, state.zones, weather) : []), [state, weather]);
  const advice = useMemo(() => (state ? buildWeatherAdvice(state.plants, state.zones, weather) : []), [state, weather]);
  const summary = useMemo(() => (state ? gardenSummary(state.plants, tasks) : null), [state, tasks]);

  async function persistPlant(plant) {
    try {
      const saved = await savePlant(state, plant);
      setState(saved);
      setToast('Plant profile saved');
      setShowEditor(false);
      setEditingPlant(null);
    } catch (error) {
      console.error(error);
      setToast('Could not save plant. Check Firebase access.');
    }
  }


  async function persistZone(zone) {
    try {
      const saved = await saveZone(state, zone);
      setState(saved);
      setShowZoneEditor(false);
      setToast('Home area saved');
    } catch (error) {
      console.error(error);
      setToast('Could not save home area. Check Firebase access.');
    }
  }


  async function removeZone(zoneId) {
    const zone = state.zones.find((item) => item.id === zoneId);
    if (!zone) return;
    if (state.zones.length <= 1) {
      setToast('At least one home area must remain');
      return;
    }
    const assignedPlants = state.plants.filter((plant) => plant.zoneId === zoneId).length;
    const confirmed = window.confirm(
      assignedPlants
        ? `Remove ${zone.name}? ${assignedPlants} plant profile(s) will move to another available area.`
        : `Remove ${zone.name} from the home map?`
    );
    if (!confirmed) return;
    try {
      const saved = await deleteZone(state, zoneId);
      setState(saved);
      setToast('Home area removed');
    } catch (error) {
      console.error(error);
      setToast('Could not remove home area. Check Firebase access.');
    }
  }
  async function removePlant(plantId) {
    const plant = state.plants.find((item) => item.id === plantId);
    const confirmed = window.confirm(`Move ${plant?.name || 'this plant'} to archive? You can restore it from Settings.`);
    if (!confirmed) return;
    const saved = await deletePlant(state, plantId);
    setState(saved);
    setLastDeletedPlant(plant || null);
    setSelectedPlant(null);
    setToast('Plant archived. Restore is available in Settings.');
  }

  async function restoreArchivedPlant(plantId) {
    const saved = await restorePlant(state, plantId);
    setState(saved);
    setLastDeletedPlant(null);
    setToast('Plant restored to garden');
  }

  async function handleCare(plantId, action, note = '') {
    try {
      const saved = await recordCareAction(state, plantId, action, note);
      setState(saved);
      setSelectedPlant((current) => (current?.id === plantId ? saved.plants.find((plant) => plant.id === plantId) || current : current));
      setToast(action === 'watered' ? 'Watering recorded' : action === 'fertilized' ? 'Fertilizer recorded' : 'Care note saved');
    } catch (error) {
      console.error(error);
      setToast('Could not record care action.');
    }
  }

  async function saveSettings(settings) {
    const saved = await updateSettings(state, settings);
    setState(saved);
    setToast('Settings updated');
  }

  async function handleMigrateData() {
    const saved = await migrateAndPersistState(state);
    setState(saved);
    setToast('Data schema checked and migrated');
  }

  async function handleSeedMissing() {
    const saved = await reseedMissingData(state);
    setState(saved);
    setToast('Missing seed plants and zones restored');
  }

  async function handleResetSeeds() {
    const confirmed = window.confirm('Reset to starter seed data? This clears current care logs and replaces visible plants with the starter garden.');
    if (!confirmed) return;
    const saved = await resetToSeedData(state);
    setState(saved);
    setToast('Starter garden reset complete');
  }

  async function handleImportBackup(backup) {
    const confirmed = window.confirm('Import this backup into Amaar Bagaan? Current Firestore data will be updated with the imported records.');
    if (!confirmed) return;
    const saved = await importGardenBackup(state, backup);
    setState(saved);
    setToast('Backup imported and synced');
  }

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(''), 2600);
    return () => clearTimeout(timer);
  }, [toast]);

  if (!authReady || loading) return <SplashScreen />;
  if (hasFirebaseConfig && !user) return <AuthScreen />;
  if (user?.allowed === false) return <BlockedScreen user={user} />;
  if (!state) return <SplashScreen />;

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar brand-topbar">
        <div className="brand-lockup">
          <BrandMark className="app-mark" />
          <div>
            <p className="eyebrow brand-bangla">আমার বাগান</p>
            <h1>Amaar Bagaan</h1>
            <p className="brand-tagline bangla-tagline">প্রতিদিনের সহজ গাছ-যত্ন</p>
          </div>
        </div>
        {activeTab === 'settings' && (
          <div className={classNames('status-pill', state.source === 'firebase' ? 'synced' : hasFirebaseConfig ? 'cache' : 'setup')}>
            {state.source === 'firebase' ? <ShieldCheck size={16} /> : hasFirebaseConfig ? <WifiOffIcon /> : <LockKeyhole size={16} />}
            {state.source === 'firebase' ? 'Cloud synced' : hasFirebaseConfig ? 'Offline cache' : 'Setup needed'}
          </div>
        )}
      </header>

      <main className="content-wrap">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <Page key="home">
              <HomeView
                state={state}
                weather={weather}
                summary={summary}
                tasks={tasks}
                advice={advice}
                onCare={handleCare}
                onAdd={() => setShowSmartAdd(true)}
                onOpenPlant={setSelectedPlant}
              />
            </Page>
          )}
          {activeTab === 'plants' && (
            <Page key="plants">
              <PlantsView
                plants={state.plants}
                zones={state.zones}
                tasks={tasks}
                onOpenPlant={setSelectedPlant}
                onAddManual={() => {
                  setEditingPlant({ ...emptyPlant, id: makeId('plant') });
                  setShowEditor(true);
                }}
                onSmartAdd={() => setShowSmartAdd(true)}
              />
            </Page>
          )}
          {activeTab === 'map' && (
            <Page key="map">
              <MapView
                plants={state.plants}
                zones={state.zones}
                tasks={tasks}
                weather={weather}
                onOpenPlant={setSelectedPlant}
                onAddZone={() => setShowZoneEditor(true)}
                onDeleteZone={removeZone}
              />
            </Page>
          )}
          {activeTab === 'care' && (
            <Page key="care">
              <CareView tasks={tasks} plants={state.plants} logs={state.careLogs} onCare={handleCare} onOpenPlant={setSelectedPlant} />
            </Page>
          )}
          {activeTab === 'settings' && (
            <Page key="settings">
              <SettingsView
                state={state}
                user={user}
                lastDeletedPlant={lastDeletedPlant}
                onSave={saveSettings}
                onToast={setToast}
                onMigrate={handleMigrateData}
                onSeedMissing={handleSeedMissing}
                onResetSeeds={handleResetSeeds}
                onImportBackup={handleImportBackup}
                onRestorePlant={restoreArchivedPlant}
              />
            </Page>
          )}
        </AnimatePresence>
      </main>

      {activeTab !== 'settings' && activeTab !== 'map' && (
        <button className="fab" onClick={() => setShowSmartAdd(true)} aria-label="Add plant">
          <Plus size={24} />
        </button>
      )}

      <nav className="bottom-nav">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.id} className={classNames('nav-item', activeTab === tab.id && 'active')} onClick={() => setActiveTab(tab.id)}>
              <Icon size={20} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      <AnimatePresence>
        {selectedPlant && (
          <PlantDetailSheet
            plant={selectedPlant}
            zones={state.zones}
            logs={state.careLogs.filter((log) => log.plantId === selectedPlant.id)}
            onClose={() => setSelectedPlant(null)}
            onCare={handleCare}
            onEdit={() => {
              setEditingPlant(selectedPlant);
              setSelectedPlant(null);
              setShowEditor(true);
            }}
            onDelete={removePlant}
          />
        )}
        {showEditor && editingPlant && (
          <PlantEditor plant={editingPlant} zones={state.zones} onClose={() => setShowEditor(false)} onSave={persistPlant} />
        )}
        {showSmartAdd && (
          <SmartAddPlant
            zones={state.zones}
            onClose={() => setShowSmartAdd(false)}
            onSave={async (plant) => {
              await persistPlant(plant);
              setShowSmartAdd(false);
            }}
          />
        )}
        {showZoneEditor && (
          <ZoneEditor
            existingCount={state.zones.length}
            onClose={() => setShowZoneEditor(false)}
            onSave={persistZone}
          />
        )}
        {toast && <Toast message={toast} />}
      </AnimatePresence>
    </div>
  );
}


function WifiOffIcon() {
  return <CloudSun size={16} />;
}

function BrandMark({ className = '' }) {
  return (
    <span className={classNames('brand-mark', className)} aria-hidden="true">
      <img src="/icons/amaar-bagaan-icon.svg" alt="" loading="eager" />
    </span>
  );
}

function Page({ children }) {
  return (
    <motion.section initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.22 }}>
      {children}
    </motion.section>
  );
}

function SplashScreen() {
  return (
    <div className="splash loading-splash">
      <div className="splash-card loading-card">
        <BrandMark className="brand-orb" />
        <p className="eyebrow bangla-eyebrow">আমার বাগান</p>
        <h1>Amaar Bagaan</h1>
        <p>Preparing weather, care tasks and plant records.</p>
        <div className="loading-bar" aria-hidden="true"><span /></div>
      </div>
    </div>
  );
}

function GoogleLogo() {
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true" focusable="false" className="google-logo">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.5-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 16.3 4 9.6 8.3 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 44c5.2 0 10-2 13.6-5.3l-6.3-5.3C29.3 35 26.8 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.5 16.2 44 24 44z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.5l6.3 5.3C39.2 37.2 44 33 44 24c0-1.3-.1-2.5-.4-3.5z"/>
    </svg>
  );
}

function AuthScreen() {
  return (
    <div className="splash auth-splash">
      <div className="splash-card auth-card premium-entry-card">
        <BrandMark className="brand-orb" />
        <p className="eyebrow">Private family garden</p>
        <h1><span className="auth-bangla-title">আমার বাগান</span><span>Amaar Bagaan</span></h1>
        <p>A calm, cloud-synced plant care space for Maa’s home garden.</p>
        <button className="primary-action google-signin" onClick={signInWithGoogle}><GoogleLogo /> Continue with Google</button>
        {allowedEmails.length > 0 && <p className="tiny-note">Only configured family emails can enter.</p>}
      </div>
    </div>
  );
}

function BlockedScreen({ user }) {
  return (
    <div className="splash">
      <div className="splash-card">
        <AlertTriangle size={42} />
        <h1>Access not allowed</h1>
        <p>{user.email} is not in the Amaar Bagaan family allow-list.</p>
        <button className="secondary-action" onClick={logout}>Sign out</button>
      </div>
    </div>
  );
}

function HomeView({ state, weather, summary, tasks, advice, onCare, onAdd, onOpenPlant }) {
  const [showBanglaTips, setShowBanglaTips] = useState(false);
  const topPlants = state.plants.slice(0, 4);
  return (
    <div className="page-stack home-page-stack">
      <section className="home-highlight-panel">
        <SectionHeader title="Garden highlights" subtitle="Recently active plants from the family garden" />
        <div className="plant-strip">
          {topPlants.map((plant) => <PlantMiniCard key={plant.id} plant={plant} zones={state.zones} onClick={() => onOpenPlant(plant)} />)}
        </div>
      </section>

      <section className="hero-card upgraded-hero-card">
        <div className="hero-illustration" aria-hidden="true"><PlantSilhouette /></div>
        <div className="hero-copy">
          <p className="eyebrow">Today in the garden</p>
          <h2>{summary?.dueToday ? <><span>{summary.dueToday}</span> care actions due</> : 'Everything looks calm today'}</h2>
          <p>
            {summary?.totalPlants} plants · {state.zones.length} care zones. Gentle weather-aware care for Maa.
          </p>
        </div>
        <button className="hero-add" onClick={onAdd}><Plus size={18} /> Add Plant</button>
      </section>

      <WeatherCard weather={weather} locationName={state.settings.locationName} />

      <div className="metric-grid">
        <MetricCard label="Plants" value={summary?.totalPlants} icon={Leaf} />
        <MetricCard label="Healthy" value={summary?.healthyCount} icon={CheckCircle2} />
        <MetricCard label="Urgent" value={summary?.highPriority} icon={AlertTriangle} />
        <MetricCard label="Watch" value={summary?.watchCount} icon={Sparkles} />
      </div>

      <div className="section-header weather-section-header">
        <div>
          <h2>Weather-aware suggestions</h2>
          <p>Daily care guidance based on local weather</p>
        </div>
        <button className={classNames('translate-toggle', showBanglaTips && 'active')} onClick={() => setShowBanglaTips((value) => !value)}><Globe2 size={15} /> বাংলা</button>
      </div>
      <div className="advice-list">
        {advice.map((item) => (
          <article key={item.title} className={classNames('advice-card', item.level)}>
            <Sparkles size={18} />
            <div>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              {showBanglaTips && item.bn && <p className="bangla-tip">{item.bn}</p>}
            </div>
          </article>
        ))}
      </div>

      <SectionHeader title="Today’s care" subtitle="Tap done after manual care" />
      <TaskList tasks={tasks.slice(0, 5)} onCare={onCare} emptyText="No urgent care pending. A quick visual leaf check is enough today." />

    </div>
  );
}

function PlantSilhouette() {
  return (
    <svg viewBox="0 0 210 150" aria-hidden="true" className="plant-hero-silhouette">
      <path className="sil-soil" d="M38 124H172" />
      <path className="sil-stem main" d="M105 122C105 91 104 66 108 35" />
      <path className="sil-leaf left" d="M101 82C70 76 49 56 45 29C74 31 96 50 101 82Z" />
      <path className="sil-leaf right" d="M113 70C143 64 162 45 168 20C139 18 118 42 113 70Z" />
      <path className="sil-leaf low" d="M101 105C77 103 62 90 58 72C80 72 97 88 101 105Z" />
      <circle className="sil-dot" cx="167" cy="96" r="7" />
      <circle className="sil-dot" cx="184" cy="94" r="5" />
    </svg>
  );
}

function WeatherCard({ weather, locationName }) {
  if (!weather) {
    return <div className="weather-card skeleton-card">Fetching local weather...</div>;
  }
  return (
    <section className="weather-card">
      <div>
        <p className="eyebrow"><CloudSun size={15} /> {locationName}</p>
        <h2>{weather.temperature}°C</h2>
        <p>{weather.condition}{weather.fallback ? ' · demo weather' : ''}</p>
      </div>
      <div className="weather-details">
        <span><ThermometerSun size={14} /> {weather.low}° / {weather.high}°</span>
        <span><Droplets size={14} /> {weather.humidity}% humidity</span>
        <span><CloudSun size={14} /> {weather.rainProbability}% rain</span>
        <span><Wind size={14} /> {weather.windSpeed} km/h</span>
      </div>
    </section>
  );
}

function MetricCard({ label, value, icon: Icon }) {
  return (
    <article className="metric-card">
      <Icon size={20} />
      <strong>{value ?? 0}</strong>
      <span>{label}</span>
    </article>
  );
}

function SectionHeader({ title, subtitle }) {
  return (
    <div className="section-header">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
    </div>
  );
}

function PlantsView({ plants, zones, tasks, onOpenPlant, onAddManual, onSmartAdd }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const dueIds = new Set(tasks.map((task) => task.plantId));
  const filtered = plants.filter((plant) => {
    const search = `${plant.name} ${plant.localName} ${plant.scientificName} ${plant.category}`.toLowerCase();
    const matchesQuery = search.includes(query.toLowerCase());
    const matchesFilter =
      filter === 'all' ||
      (filter === 'due' && dueIds.has(plant.id)) ||
      (filter === 'indoor' && plant.indoorOutdoor === 'indoor') ||
      (filter === 'outdoor' && plant.indoorOutdoor === 'outdoor') ||
      plant.zoneId === filter;
    return matchesQuery && matchesFilter;
  });

  return (
    <div className="page-stack">
      <div className="title-row">
        <div>
          <p className="eyebrow">Plant inventory</p>
          <h2>{plants.length} living profiles</h2>
        </div>
        <button className="pill-button" onClick={onSmartAdd}><Sparkles size={16} /> Smart Add</button>
      </div>
      <div className="search-card">
        <Search size={18} />
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search Tulsi, rose, indoor..." />
      </div>
      <div className="filter-row">
        {['all', 'due', 'indoor', 'outdoor', ...zones.map((zone) => zone.id)].map((item, index) => (
          <button key={`${item}-${index}`} className={classNames(filter === item && 'active')} onClick={() => setFilter(item)}>
            {item === 'all' ? 'All' : item === 'due' ? 'Care Due' : item === 'indoor' ? 'Indoor' : item === 'outdoor' ? 'Outdoor' : zones.find((zone) => zone.id === item)?.name}
          </button>
        ))}
      </div>
      <div className="plant-grid">
        {filtered.map((plant) => <PlantCard key={plant.id} plant={plant} zones={zones} isDue={dueIds.has(plant.id)} onClick={() => onOpenPlant(plant)} />)}
      </div>
      <button className="secondary-wide" onClick={onAddManual}><Plus size={18} /> Add manually</button>
    </div>
  );
}

function PlantCard({ plant, zones, isDue, onClick }) {
  const zone = zones.find((item) => item.id === plant.zoneId);
  return (
    <button className="plant-card" onClick={onClick}>
      <PlantImage plant={plant} />
      <div className="plant-card-body">
        <div>
          <h3>{plant.name}</h3>
          <p>{plant.localName || plant.scientificName || plant.category}</p>
        </div>
        <div className="plant-tags">
          <span>{zone?.name || 'No zone'}</span>
          {isDue && <span className="due-tag">Due</span>}
        </div>
      </div>
    </button>
  );
}

function PlantMiniCard({ plant, zones, onClick }) {
  const zone = zones.find((item) => item.id === plant.zoneId);
  return (
    <button className="mini-plant" onClick={onClick}>
      <PlantImage plant={plant} />
      <h3>{plant.name}</h3>
      <p>{zone?.name || plant.category}</p>
    </button>
  );
}

function PlantImage({ plant }) {
  if (plant.imageUrl) {
    return <img className="plant-image" src={plant.imageUrl} alt={plant.name} loading="lazy" onError={(event) => { event.currentTarget.style.display = 'none'; }} />;
  }
  return (
    <div className="plant-image placeholder"><Flower2 size={30} /></div>
  );
}


const ZONE_VISUAL_SLOTS = {
  'roof-west': { x: 17, y: 18 },
  'roof-east': { x: 82, y: 18 },
  'roof-north': { x: 50, y: 27 },
  'boundary-wall-west': { x: 18, y: 50 },
  'boundary-wall-east': { x: 82, y: 50 },
  'boundary-wall': { x: 50, y: 62 },
  veranda: { x: 18, y: 80 },
  staircase: { x: 50, y: 80 },
  indoor: { x: 82, y: 80 },
  entrance: { x: 50, y: 91 }
};

const EXTRA_ZONE_VISUAL_SLOTS = [
  { x: 33, y: 36 }, { x: 67, y: 36 }, { x: 32, y: 66 }, { x: 68, y: 66 },
  { x: 50, y: 45 }, { x: 28, y: 22 }, { x: 72, y: 22 }, { x: 28, y: 86 }, { x: 72, y: 86 }
];

function zoneVisualPoint(zone, index = 0) {
  if (ZONE_VISUAL_SLOTS[zone.id]) return ZONE_VISUAL_SLOTS[zone.id];
  return EXTRA_ZONE_VISUAL_SLOTS[Math.max(0, index - Object.keys(ZONE_VISUAL_SLOTS).length) % EXTRA_ZONE_VISUAL_SLOTS.length];
}

function MapView({ plants, zones, tasks, weather, onOpenPlant, onAddZone, onDeleteZone }) {
  const [selectedZoneId, setSelectedZoneId] = useState(zones[0]?.id || '');
  useEffect(() => {
    if (!zones.some((zone) => zone.id === selectedZoneId)) setSelectedZoneId(zones[0]?.id || '');
  }, [zones, selectedZoneId]);

  const taskIds = new Set(tasks.map((task) => task.plantId));
  const selectedZone = zones.find((zone) => zone.id === selectedZoneId) || zones[0];
  const selectedPlants = plants.filter((plant) => plant.zoneId === selectedZone?.id);
  const selectedTasks = tasks.filter((task) => task.zoneId === selectedZone?.id || selectedPlants.some((plant) => plant.id === task.plantId));
  const selectedRisk = zoneRisk(selectedZone, selectedPlants, selectedTasks, weather);

  return (
    <div className="page-stack map-page-v134">
      <div className="title-row map-title-row refined-map-title">
        <div>
          <p className="eyebrow">House garden map</p>
          <h2>Smart care map</h2>
          <p>Tap a point to focus one home area. Zones track sunlight, rain, airflow and care needs.</p>
        </div>
        <button className="pill-button area-add-button" onClick={onAddZone}><Plus size={16} /> Add area</button>
      </div>

      <div className="map-panel garden-orbit-panel">
        <div className="house-map garden-orbit-map" aria-label="Interactive garden care map">
          <div className="map-compass-card" aria-hidden="true">
            <span className="north">N</span>
            <span className="east">E</span>
            <Navigation size={19} />
            <span className="west">W</span>
            <span className="south">S</span>
          </div>
          <div className="map-house-outline" aria-hidden="true">
            <span className="map-roof-line" />
            <span className="map-courtyard-ring" />
            <span className="map-path north" />
            <span className="map-path east" />
            <span className="map-path south" />
            <span className="map-path west" />
          </div>
          {selectedZone && (
            <div className="map-selected-badge" aria-hidden="true">
              <strong>{selectedZone.name}</strong>
              <span>{selectedPlants.length} plants · {selectedTasks.length} due</span>
            </div>
          )}
          {zones.map((zone, index) => {
            const zonePlants = plants.filter((plant) => plant.zoneId === zone.id);
            const zoneTasks = tasks.filter((task) => task.zoneId === zone.id || zonePlants.some((plant) => plant.id === task.plantId));
            const risk = zoneRisk(zone, zonePlants, zoneTasks, weather);
            const point = zoneVisualPoint(zone, index);
            return (
              <button
                key={zone.id}
                className={classNames('zone-pin', 'risk-' + risk.level, selectedZone?.id === zone.id && 'selected')}
                style={{ left: point.x + '%', top: point.y + '%' }}
                onClick={() => setSelectedZoneId(zone.id)}
                aria-label={`Open ${zone.name}`}
              >
                <span className="zone-pin-dot"><span>{zoneTasks.length || zonePlants.length || index + 1}</span></span>
                <span className="zone-pin-label"><strong>{zone.name}</strong></span>
              </button>
            );
          })}
        </div>
        <p className="map-helper"><Compass size={15} /> Care points are practical home areas for plant-care guidance.</p>
      </div>

      {selectedZone && (
        <article className={classNames('zone-focus-card', 'risk-' + selectedRisk.level, 'zone-command-card')}>
          <div className="zone-focus-top">
            <div>
              <p className="eyebrow">Focused home area</p>
              <h3>{selectedZone.name}</h3>
              <p>{selectedZone.description || 'Care conditions for this home area are tracked here.'}</p>
            </div>
            <div className="zone-focus-actions">
              <strong>{selectedRisk.label}</strong>
              <button className="zone-remove-icon" onClick={() => onDeleteZone(selectedZone.id)} aria-label="Remove area"><Trash2 size={15} /></button>
            </div>
          </div>
          <div className="zone-metrics-row zone-command-metrics">
            <span><Leaf size={15} /> {selectedPlants.length} plants</span>
            <span><Clock3 size={15} /> {selectedTasks.length} care due</span>
            <span><ThermometerSun size={15} /> {selectedZone.heatRisk || 'normal'} heat</span>
          </div>
          <div className="zone-condition-grid zone-condition-grid-pro">
            <span><strong>Sunlight</strong>{selectedZone.sunlightProfile || 'mixed light'}</span>
            <span><strong>Shade</strong>{selectedZone.shadeLevel || 'partial shade'}</span>
            <span><strong>Airflow</strong>{selectedZone.airflow || 'moderate'}</span>
            <span><strong>Rain</strong>{selectedZone.rainExposure || 'medium'}</span>
            <span><strong>Wind</strong>{selectedZone.windRisk || 'medium'}</span>
            <span><strong>Humidity</strong>{selectedZone.humidityProfile || 'normal'}</span>
          </div>
          {selectedRisk.reasons?.length > 0 && (
            <div className="risk-reasons">
              {selectedRisk.reasons.map((reason) => <span key={reason}>{reason}</span>)}
            </div>
          )}
          <SectionHeader title="Plants in this area" subtitle="Tap a plant to open its care sheet" />
          <div className="zone-plant-grid">
            {selectedPlants.map((plant) => (
              <button key={plant.id} className={classNames('zone-plant-chip', taskIds.has(plant.id) && 'due')} onClick={() => onOpenPlant(plant)}>
                <PlantImage plant={plant} />
                <span>{plant.name}</span>
              </button>
            ))}
            {selectedPlants.length === 0 && <div className="empty-card">No plants placed in this area yet. Add a plant or edit an existing profile to assign it here.</div>}
          </div>
        </article>
      )}
    </div>
  );
}

function ZoneEditor({ existingCount, onClose, onSave }) {
  const [form, setForm] = useState({
    id: makeId('zone'),
    name: '',
    banglaName: '',
    type: 'custom',
    description: '',
    sunlightProfile: 'mixed-light',
    shadeLevel: 'partial-shade',
    heatRisk: 'medium',
    rainExposure: 'medium',
    windRisk: 'medium',
    humidityProfile: 'normal',
    airflow: 'moderate',
    sortOrder: existingCount + 1,
    map: { x: 48, y: 88, w: 24, h: 10 }
  });

  const placementPresets = [
    { label: 'North roof', map: { x: 42, y: 18, w: 24, h: 12 } },
    { label: 'East side', map: { x: 76, y: 46, w: 22, h: 12 } },
    { label: 'South entrance', map: { x: 48, y: 88, w: 24, h: 10 } },
    { label: 'West side', map: { x: 14, y: 46, w: 22, h: 12 } },
    { label: 'Indoor corner', map: { x: 68, y: 74, w: 22, h: 12 } },
    { label: 'Veranda area', map: { x: 26, y: 74, w: 22, h: 12 } }
  ];
  const setValue = (field, value) => setForm((current) => ({ ...current, [field]: value }));
  const applyPreset = (preset) => setForm((current) => ({ ...current, map: preset.map }));

  return (
    <motion.div className="sheet-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.article className="editor-sheet zone-editor-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} onClick={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <p className="eyebrow"><MapPin size={15} /> Home area intelligence</p>
        <h2>Add a new home area</h2>
        <p className="muted">Create areas like south balcony, inner courtyard, mother’s kitchen window or west boundary. Zone conditions are used by care logic.</p>
        <div className="form-grid compact-form-grid">
          <label>Name<input value={form.name} onChange={(event) => setValue('name', event.target.value)} placeholder="South balcony" /></label>
          <label>Bengali name<input value={form.banglaName} onChange={(event) => setValue('banglaName', event.target.value)} placeholder="দক্ষিণ বারান্দা" /></label>
          <label>Type<select value={form.type} onChange={(event) => setValue('type', event.target.value)}><option value="roof">Roof</option><option value="boundary">Boundary</option><option value="indoor">Indoor</option><option value="semi-outdoor">Semi-outdoor</option><option value="custom">Custom</option></select></label>
          <label>Sunlight<select value={form.sunlightProfile} onChange={(event) => setValue('sunlightProfile', event.target.value)}><option value="full-sun">Full sun</option><option value="morning-sun">Morning sun</option><option value="afternoon-sun">Afternoon sun</option><option value="mixed-light">Mixed light</option><option value="indirect-light">Indirect light</option><option value="filtered-light">Filtered light</option></select></label>
          <label>Shade<select value={form.shadeLevel} onChange={(event) => setValue('shadeLevel', event.target.value)}><option value="no-shade">No shade</option><option value="partial-shade">Partial shade</option><option value="deep-shade">Deep shade</option></select></label>
          <label>Heat risk<select value={form.heatRisk} onChange={(event) => setValue('heatRisk', event.target.value)}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
          <label>Rain exposure<select value={form.rainExposure} onChange={(event) => setValue('rainExposure', event.target.value)}><option value="none">None</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
          <label>Wind risk<select value={form.windRisk} onChange={(event) => setValue('windRisk', event.target.value)}><option value="none">None</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
          <label>Humidity<select value={form.humidityProfile} onChange={(event) => setValue('humidityProfile', event.target.value)}><option value="dry">Dry</option><option value="normal">Normal</option><option value="humid">Humid</option></select></label>
          <label>Airflow<select value={form.airflow} onChange={(event) => setValue('airflow', event.target.value)}><option value="low">Low</option><option value="moderate">Moderate</option><option value="high">High</option></select></label>
          <label className="wide">Description<textarea value={form.description} onChange={(event) => setValue('description', event.target.value)} placeholder="What makes this area different for plant care?" /></label>
          <div className="wide placement-picker">
            <strong>Place this area on the home map</strong>
            <p>Choose a simple direction. No X/Y values needed.</p>
            <div>
              {placementPresets.map((preset) => (
                <button key={preset.label} type="button" className="secondary-action" onClick={() => applyPreset(preset)}>{preset.label}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="editor-actions">
          <button className="secondary-action" onClick={onClose}>Cancel</button>
          <button className="primary-action" onClick={() => onSave({ ...form, name: form.name.trim() || 'New home area' })}>Save area</button>
        </div>
      </motion.article>
    </motion.div>
  );
}


function CareView({ tasks, plants, logs, onCare, onOpenPlant }) {
  return (
    <div className="page-stack">
      <div className="title-row">
        <div>
          <p className="eyebrow">Care board</p>
          <h2>{tasks.length ? `${tasks.length} actions pending` : 'No care backlog'}</h2>
        </div>
      </div>
      <TaskList tasks={tasks} onCare={onCare} emptyText="No watering or fertilizer due right now." />
      <SectionHeader title="Recent care history" subtitle="Manual actions recorded for the garden" />
      <div className="log-list">
        {logs.slice(0, 12).map((log) => {
          const plant = plants.find((item) => item.id === log.plantId);
          return (
            <button key={log.id} className="log-card" onClick={() => plant && onOpenPlant(plant)}>
              <span className="log-icon"><CareLogIcon action={log.action} /></span>
              <div>
                <h3>{plant?.name || 'Plant'}</h3>
                <p>{log.action} · {formatFriendlyDate(log.createdAt)} {formatTime(log.createdAt)}</p>
              </div>
            </button>
          );
        })}
        {logs.length === 0 && <div className="empty-card">No care logs yet. Mark watering once to begin the diary.</div>}
      </div>
    </div>
  );
}


function CareLogIcon({ action }) {
  if (action === 'watered') return <Droplets size={19} />;
  if (action === 'fertilized') return <Sprout size={19} />;
  return <FileText size={19} />;
}

function TaskList({ tasks, onCare, emptyText }) {
  if (!tasks.length) {
    return (
      <div className="empty-state-card">
        <CheckCircle2 size={26} />
        <strong>All clear for now</strong>
        <p>{emptyText}</p>
      </div>
    );
  }
  return (
    <div className="task-list">
      {tasks.map((task) => (
        <article key={task.id} className={classNames('task-card', task.priority)}>
          <div className="task-icon">{task.type === 'fertilized' ? <Sprout size={19} /> : <Droplets size={19} />}</div>
          <div>
            <span className="task-kicker">{task.priority === 'high' ? 'Priority' : task.priority === 'watch' ? 'Check first' : 'Routine'}</span>
            <h3>{task.title}</h3>
            <p>{task.zoneName} · {task.guidance}</p>
          </div>
          <button onClick={() => onCare(task.plantId, task.type)}>Done</button>
        </article>
      ))}
    </div>
  );
}
function SettingsView({ state, user, lastDeletedPlant, onSave, onToast, onMigrate, onSeedMissing, onResetSeeds, onImportBackup, onRestorePlant }) {
  const [form, setForm] = useState(state.settings);

  useEffect(() => {
    setForm(state.settings);
  }, [state.settings]);

  function exportData() {
    const payload = {
      exportedAt: new Date().toISOString(),
      app: 'Amaar Bagaan',
      version: '1.3.7',
      plants: state.plants,
      deletedPlants: state.deletedPlants || [],
      zones: state.zones,
      careLogs: state.careLogs,
      settings: state.settings,
      meta: state.meta
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `amaar-bagaan-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    onToast('Backup exported');
  }

  function importData(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const backup = JSON.parse(String(reader.result || '{}'));
        await onImportBackup(backup);
      } catch (error) {
        console.error(error);
        onToast('Invalid backup file');
      } finally {
        event.target.value = '';
      }
    };
    reader.readAsText(file);
  }

  const archivedPlant = lastDeletedPlant || state.deletedPlants?.[0];
  const isCloud = state.source === 'firebase';
  const modeTitle = isCloud ? 'Cloud garden is active' : hasFirebaseConfig ? 'Cloud configured, using local cache' : 'Firebase setup is not connected';
  const modeText = isCloud
    ? 'Your family garden data is safely syncing with Firestore.'
    : hasFirebaseConfig
      ? 'Cloud setup is available, but this device is currently showing cached garden data.'
      : 'Connect Firebase to keep the garden synced across devices.';
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    setIsStandalone(window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone === true);
    const handler = (event) => {
      event.preventDefault();
      setInstallPrompt(event);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  async function installApp() {
    if (isStandalone) {
      onToast('Amaar Bagaan is already installed');
      return;
    }
    if (installPrompt) {
      installPrompt.prompt();
      const result = await installPrompt.userChoice;
      setInstallPrompt(null);
      if (result?.outcome === 'accepted') {
        setIsStandalone(true);
        onToast('Amaar Bagaan install started');
      } else {
        onToast('Install was cancelled');
      }
      return;
    }
    const liveUrl = 'https://amaar-bagaan.web.app/';
    const isLocal = ['localhost', '127.0.0.1', '0.0.0.0'].includes(window.location.hostname) || window.location.hostname.startsWith('192.168.');
    if (isLocal) {
      window.open(liveUrl, '_blank', 'noopener,noreferrer');
      onToast('Live app opened. Use the Install app button there.');
      return;
    }
    try {
      await navigator.clipboard?.writeText(window.location.href);
      onToast('App link copied. Chrome shows Install when PWA criteria are ready.');
    } catch {
      onToast('Use Chrome menu → Add to Home screen if the install prompt is hidden.');
    }
  }
  return (
    <div className="page-stack settings-v131">
      <div className="title-row">
        <div>
          <p className="eyebrow">Settings</p>
          <h2>Garden controls</h2>
          <p>Everyday controls are kept simple. Technical tools stay tucked away below.</p>
        </div>
      </div>

      <section className={classNames('settings-card settings-hero-card sync-state-card', isCloud ? 'synced' : 'cache')}>
        <div className="settings-hero-copy">
          {isCloud ? <ShieldCheck size={23} /> : <Database size={23} />}
          <div>
            <h3>{modeTitle}</h3>
            <p>{modeText}</p>
            {user?.email && <span>{user.email}</span>}
          </div>
        </div>
        <div className="settings-quick-row">
          <button className="secondary-action on-dark" onClick={() => window.location.reload()}><RefreshCcw size={17} /> Refresh</button>
          {hasFirebaseConfig && <button className="secondary-action on-dark" onClick={logout}><LogOut size={17} /> Sign out</button>}
        </div>
      </section>

      <section className="settings-card weather-map-card">
        <div className="weather-map-visual">
          <div className="mini-compass"><span>N</span><Navigation size={20} /><span>S</span></div>
          <MapPin size={32} />
          <strong>{form.locationName || 'Garden location'}</strong>
          <p>{form.latitude}, {form.longitude}</p>
        </div>
        <div className="card-heading-row">
          <div>
            <h3>Weather location</h3>
            <p>This location powers rain, heat, humidity and wind guidance for your mother’s garden.</p>
          </div>
        </div>
        <label>
          Location name
          <input value={form.locationName} onChange={(event) => setForm({ ...form, locationName: event.target.value })} />
        </label>
        <div className="two-col">
          <label>
            Latitude
            <input value={form.latitude} onChange={(event) => setForm({ ...form, latitude: event.target.value })} />
          </label>
          <label>
            Longitude
            <input value={form.longitude} onChange={(event) => setForm({ ...form, longitude: event.target.value })} />
          </label>
        </div>
        <button className="primary-action" onClick={() => onSave(form)}>Save weather location</button>
      </section>

      <section className="settings-card install-card">
        <div className="install-visual"><Smartphone size={25} /><BrandMark className="mini-install-mark" /></div>
        <div>
          <h3>Install on phone</h3>
          <p>Add Amaar Bagaan to the phone home screen for quick, secure garden access.</p>
        </div>
        <button className="primary-action" onClick={installApp}>{isStandalone ? 'Already installed' : 'Install app'}</button>
      </section>

      <section className="settings-card compact release-card clean-release-card">
        <h3>Garden status</h3>
        <p>App version 1.3.7 · Schema v{state.meta?.schemaVersion || 4}</p>
        <p>{state.plants.length} active plants · {(state.deletedPlants || []).length} archived · {state.careLogs.length} care logs</p>
        {state.settings?.lastMigratedAt && <p>Last maintenance: {formatFriendlyDate(state.settings.lastMigratedAt)} {formatTime(state.settings.lastMigratedAt)}</p>}
        <p className="made-by-line"><Heart size={15} /> Made by Akash Patra © 2026</p>
      </section>

      <details className="advanced-tools">
        <summary><SlidersIcon /> Caretaker and developer tools</summary>
        <section className="settings-card">
          <div className="card-heading-row">
            <div>
              <h3>Backup and restore</h3>
              <p>Useful for you, not for daily garden care. Keep backups before major edits.</p>
            </div>
          </div>
          <div className="action-grid">
            <button className="secondary-action" onClick={exportData}><Download size={17} /> Export backup</button>
            <label className="file-action">
              <Upload size={17} /> Import backup
              <input type="file" accept="application/json,.json" onChange={importData} />
            </label>
          </div>
        </section>

        <section className="settings-card">
          <div className="card-heading-row">
            <div>
              <h3>Data maintenance</h3>
              <p>Use only while validating releases or repairing seed data.</p>
            </div>
          </div>
          <div className="action-grid stacked-mobile">
            <button className="secondary-action" onClick={onMigrate}><Database size={17} /> Migrate schema</button>
            <button className="secondary-action" onClick={onSeedMissing}><RefreshCcw size={17} /> Safe seed check</button>
            <button className="secondary-action" onClick={onResetSeeds}><RotateCcw size={17} /> Reset seed data</button>
            {archivedPlant && <button className="secondary-action" onClick={() => onRestorePlant(archivedPlant.id)}><ArchiveRestore size={17} /> Restore {archivedPlant.name}</button>}
          </div>
        </section>
      </details>
    </div>
  );
}

function SlidersIcon() {
  return <Settings size={16} />;
}

function PlantDetailSheet({ plant, zones, logs, onClose, onCare, onEdit, onDelete }) {
  const zone = zones.find((item) => item.id === plant.zoneId);
  const nextWater = plant.lastWateredAt ? addDays(plant.lastWateredAt, plant.waterFrequencyDays) : null;
  const nextFertilizer = plant.lastFertilizedAt ? addDays(plant.lastFertilizedAt, plant.fertilizerFrequencyDays) : null;
  return (
    <motion.div className="sheet-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.article className="plant-sheet premium-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 260 }} onClick={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <button className="sheet-close" onClick={onClose} aria-label="Close plant details"><X size={18} /></button>
        <div className="plant-hero-image"><PlantImage plant={plant} /></div>
        <div className="sheet-title">
          <div>
            <p className="eyebrow">{zone?.name || 'Unassigned'} · {plant.category}</p>
            <h2>{plant.name}</h2>
            <p>{plant.localName || plant.scientificName || 'Personal garden profile'}</p>
          </div>
          <button onClick={onEdit} aria-label="Edit plant"><Edit3 size={18} /></button>
        </div>
        <p className="plant-summary">{plant.summary || 'No summary yet. Add care notes from observation.'}</p>

        <div className="care-status-row">
          <span><Clock3 size={16} /> Water: {plant.lastWateredAt ? formatFriendlyDate(plant.lastWateredAt) : 'Not recorded'}</span>
          <span><Sprout size={16} /> Feed: {plant.lastFertilizedAt ? formatFriendlyDate(plant.lastFertilizedAt) : 'Not recorded'}</span>
        </div>

        <div className="quick-actions">
          <button onClick={() => onCare(plant.id, 'watered')}><Droplets size={18} /> Watered</button>
          <button onClick={() => onCare(plant.id, 'fertilized')}><Sprout size={18} /> Fertilized</button>
        </div>
        <div className="detail-grid premium-detail-grid">
          <span><strong>Sunlight</strong>{plant.sunlight}</span>
          <span><strong>Soil</strong>{plant.soilType || 'Not set'}</span>
          <span><strong>Next water</strong>{nextWater ? formatShortDate(nextWater) : 'Start tracking'}</span>
          <span><strong>Next fertilizer</strong>{nextFertilizer ? formatShortDate(nextFertilizer) : 'Start tracking'}</span>
        </div>
        <CareNotes title="Care dos" items={plant.careDos} />
        <CareNotes title="Care don’ts" items={plant.careDonts} />
        <SectionHeader title="Care history" subtitle="Latest manual actions" />
        <div className="log-list mini">
          {logs.slice(0, 6).map((log) => <div key={log.id} className="log-card"><span className="log-icon"><CareLogIcon action={log.action} /></span><p>{log.action} · {formatFriendlyDate(log.createdAt)} {formatTime(log.createdAt)}</p></div>)}
          {logs.length === 0 && <div className="empty-card">No history yet. Use Watered or Fertilized to begin the plant diary.</div>}
        </div>
        <button className="danger-action" onClick={() => onDelete(plant.id)}><Trash2 size={16} /> Archive plant</button>
      </motion.article>
    </motion.div>
  );
}
function CareNotes({ title, items = [] }) {
  return (
    <div className="care-note-box">
      <h3>{title}</h3>
      <ul>
        {items.map((item) => <li key={item}>{item}</li>)}
      </ul>
    </div>
  );
}

function PlantEditor({ plant, zones, onClose, onSave }) {
  const [form, setForm] = useState({ ...emptyPlant, ...plant });
  const setValue = (field, value) => setForm((current) => ({ ...current, [field]: value }));
  const listValue = (items) => Array.isArray(items) ? items.join('\n') : '';

  return (
    <motion.div className="sheet-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.article className="editor-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} onClick={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <h2>{plant.name ? 'Edit plant' : 'Add plant'}</h2>
        <div className="form-grid">
          <label>Name<input value={form.name} onChange={(event) => setValue('name', event.target.value)} /></label>
          <label>Local/Bengali name<input value={form.localName || ''} onChange={(event) => setValue('localName', event.target.value)} /></label>
          <label>Scientific name<input value={form.scientificName || ''} onChange={(event) => setValue('scientificName', event.target.value)} /></label>
          <label>Category<input value={form.category || ''} onChange={(event) => setValue('category', event.target.value)} /></label>
          <label>Zone<select value={form.zoneId} onChange={(event) => setValue('zoneId', event.target.value)}>{zones.map((zone) => <option key={zone.id} value={zone.id}>{zone.name}</option>)}</select></label>
          <label>Indoor / Outdoor<select value={form.indoorOutdoor} onChange={(event) => setValue('indoorOutdoor', event.target.value)}><option value="indoor">Indoor</option><option value="outdoor">Outdoor</option></select></label>
          <label>Sunlight<input value={form.sunlight || ''} onChange={(event) => setValue('sunlight', event.target.value)} /></label>
          <label>Water every N days<input type="number" min="0" value={form.waterFrequencyDays || 0} onChange={(event) => setValue('waterFrequencyDays', Number(event.target.value))} /></label>
          <label>Fertilizer every N days<input type="number" min="0" value={form.fertilizerFrequencyDays || 0} onChange={(event) => setValue('fertilizerFrequencyDays', Number(event.target.value))} /></label>
          <label>Soil type<input value={form.soilType || ''} onChange={(event) => setValue('soilType', event.target.value)} /></label>
          <label className="wide">Image URL<input value={form.imageUrl || ''} onChange={(event) => setValue('imageUrl', event.target.value)} /></label>
          <label className="wide">Summary<textarea value={form.summary || ''} onChange={(event) => setValue('summary', event.target.value)} /></label>
          <label className="wide">Care dos<textarea value={listValue(form.careDos)} onChange={(event) => setValue('careDos', event.target.value.split('\n').filter(Boolean))} /></label>
          <label className="wide">Care don’ts<textarea value={listValue(form.careDonts)} onChange={(event) => setValue('careDonts', event.target.value.split('\n').filter(Boolean))} /></label>
        </div>
        <div className="editor-actions">
          <button className="secondary-action" onClick={onClose}>Cancel</button>
          <button className="primary-action" onClick={() => onSave({ ...form, id: form.id || makeId('plant'), verifiedByUser: true })}>Save plant</button>
        </div>
      </motion.article>
    </motion.div>
  );
}

function SmartAddPlant({ zones, onClose, onSave }) {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [plant, setPlant] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const setValue = (field, value) => setPlant((current) => ({ ...current, [field]: value }));
  const listValue = (items) => Array.isArray(items) ? items.join('\n') : '';
  const listFromText = (value) => value.split('\n').map((item) => item.trim()).filter(Boolean);

  async function searchPlant() {
    if (!query.trim()) {
      setError('Enter a plant name first.');
      return;
    }
    setLoading(true);
    setError('');
    setResult(null);
    setPlant(null);
    try {
      const enriched = await enrichPlantByName(query);
      setResult(enriched);
      setPlant(enriched.profile);
    } catch (err) {
      setError(err.message || 'Unable to enrich plant');
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div className="sheet-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.article className="editor-sheet smart-sheet smart-v13-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} onClick={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <p className="eyebrow"><Sparkles size={15} /> Smart Add Plant</p>
        <h2>Type a plant name</h2>
        <p className="muted">Amaar Bagaan will lookup Wikipedia/Wikidata, pick a reference image when available, then apply a care-template fallback. Review and correct before saving.</p>
        <div className="smart-search">
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Tulsi, Rose, Aloe vera..." onKeyDown={(event) => event.key === 'Enter' && searchPlant()} />
          <button onClick={searchPlant} disabled={loading}>{loading ? 'Searching...' : 'Lookup'}</button>
        </div>
        {error && <div className="error-card">{error}</div>}
        {loading && <div className="smart-loading-card"><Sparkles size={20} /> Fetching plant identity, image and care template...</div>}
        {plant && (
          <div className="smart-preview smart-review-grid">
            <div className="smart-profile-hero">
              <PlantImage plant={plant} />
              <div className="confidence-card">
                <span>{plant.confidence || 50}%</span>
                <strong>{plant.confidenceLabel || 'Review carefully'}</strong>
                <p>{plant.careTemplateName || 'Care template fallback'}</p>
              </div>
            </div>
            <div className="source-chip-row">
              <span className={result?.sourceHealth?.wikipedia ? 'ok' : 'warn'}>Wikipedia {result?.sourceHealth?.wikipedia ? 'found' : 'fallback'}</span>
              <span className={result?.sourceHealth?.wikidata ? 'ok' : 'warn'}>Wikidata {result?.sourceHealth?.wikidata ? 'found' : 'fallback'}</span>
              <span className={result?.sourceHealth?.image ? 'ok' : 'warn'}>Image {result?.sourceHealth?.image ? 'found' : 'manual needed'}</span>
            </div>
            <div className="form-grid compact-form-grid">
              <label>Name<input value={plant.name || ''} onChange={(event) => setValue('name', event.target.value)} /></label>
              <label>Local/Bengali name<input value={plant.localName || ''} onChange={(event) => setValue('localName', event.target.value)} /></label>
              <label>Scientific name<input value={plant.scientificName || ''} onChange={(event) => setValue('scientificName', event.target.value)} /></label>
              <label>Category<input value={plant.category || ''} onChange={(event) => setValue('category', event.target.value)} /></label>
              <label>Zone<select value={plant.zoneId} onChange={(event) => setValue('zoneId', event.target.value)}>{zones.map((zone) => <option key={zone.id} value={zone.id}>{zone.name}</option>)}</select></label>
              <label>Indoor / Outdoor<select value={plant.indoorOutdoor} onChange={(event) => setValue('indoorOutdoor', event.target.value)}><option value="indoor">Indoor</option><option value="outdoor">Outdoor</option></select></label>
              <label>Sunlight<input value={plant.sunlight || ''} onChange={(event) => setValue('sunlight', event.target.value)} /></label>
              <label>Water every N days<input type="number" min="0" value={plant.waterFrequencyDays || 0} onChange={(event) => setValue('waterFrequencyDays', Number(event.target.value))} /></label>
              <label>Fertilizer every N days<input type="number" min="0" value={plant.fertilizerFrequencyDays || 0} onChange={(event) => setValue('fertilizerFrequencyDays', Number(event.target.value))} /></label>
              <label>Soil type<input value={plant.soilType || ''} onChange={(event) => setValue('soilType', event.target.value)} /></label>
              <label className="wide">Reference image URL<input value={plant.imageUrl || ''} onChange={(event) => setValue('imageUrl', event.target.value)} /></label>
              <label className="wide">Summary<textarea value={plant.summary || ''} onChange={(event) => setValue('summary', event.target.value)} /></label>
              <label className="wide">Care dos<textarea value={listValue(plant.careDos)} onChange={(event) => setValue('careDos', listFromText(event.target.value))} /></label>
              <label className="wide">Care don’ts<textarea value={listValue(plant.careDonts)} onChange={(event) => setValue('careDonts', listFromText(event.target.value))} /></label>
            </div>
            {plant.sourceUrl && <a className="source-link" href={plant.sourceUrl} target="_blank" rel="noreferrer">Open source reference</a>}
            {result?.matches?.length > 0 && (
              <div className="match-box match-box-v13">
                <h4>Source candidates</h4>
                {result.matches.slice(0, 6).map((match) => <p key={match.source + '-' + match.title}><strong>{match.source}</strong> · {match.title}<br /><span>{match.snippet}</span></p>)}
              </div>
            )}
            {plant.sourceNote && <div className="smart-note-card">{plant.sourceNote}</div>}
            <button className="primary-action" onClick={() => onSave({ ...plant, id: plant.id || makeId('plant'), verifiedByUser: true, lifecycle: { ...(plant.lifecycle || {}), verifiedByUser: true, sourceGenerated: true, createdFrom: 'smart-add-v1.3' } })}>Save reviewed profile</button>
          </div>
        )}
      </motion.article>
    </motion.div>
  );
}


function Toast({ message }) {
  return (
    <motion.div className="toast" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}>
      {message}
    </motion.div>
  );
}
