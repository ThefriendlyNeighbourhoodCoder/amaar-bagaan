export function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value?.toDate === 'function') return value.toDate();
  if (typeof value === 'object' && typeof value.seconds === 'number') {
    return new Date(value.seconds * 1000 + Math.floor((value.nanoseconds || 0) / 1000000));
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function toIso(value) {
  const date = toDate(value);
  return date ? date.toISOString() : null;
}

export function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

export function daysBetween(fromValue, toValue = new Date()) {
  const from = toDate(fromValue);
  const to = toDate(toValue);
  if (!from || !to) return Infinity;
  const fromStart = new Date(from);
  fromStart.setHours(0, 0, 0, 0);
  const toStart = new Date(to);
  toStart.setHours(0, 0, 0, 0);
  return Math.floor((toStart - fromStart) / 86400000);
}

export function addDays(value, days) {
  const date = toDate(value) || new Date();
  const next = new Date(date);
  next.setDate(next.getDate() + Number(days || 0));
  return next;
}

export function formatFriendlyDate(value) {
  const date = toDate(value);
  if (!date) return 'Not recorded';
  const todayDiff = daysBetween(date);
  if (todayDiff === 0) return 'Today';
  if (todayDiff === 1) return 'Yesterday';
  if (todayDiff < 7) return `${todayDiff} days ago`;
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function formatShortDate(value) {
  const date = toDate(value);
  if (!date) return 'Not planned';
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function formatTime(value) {
  const date = toDate(value);
  if (!date) return '';
  return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}
