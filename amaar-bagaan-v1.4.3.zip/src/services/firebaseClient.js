import { initializeApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import {
  getFirestore,
  collection,
  getDocs,
  getDoc,
  addDoc,
  setDoc,
  doc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

export const hasFirebaseConfig = Boolean(
  firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId
);

export const allowedEmails = (import.meta.env.VITE_ALLOWED_EMAILS || '')
  .split(',')
  .map((email) => email.trim().toLowerCase())
  .filter(Boolean);

const app = hasFirebaseConfig ? getApps()[0] || initializeApp(firebaseConfig) : null;
export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
export const firestoreTimestamp = serverTimestamp;

export function listenToAuth(callback) {
  if (!auth) {
    callback({ mode: 'demo', email: 'local-demo@amaar-bagaan.app', displayName: 'Amaar Bagaan Demo' });
    return () => {};
  }
  return onAuthStateChanged(auth, (user) => {
    if (!user) {
      callback(null);
      return;
    }

    const email = user.email?.toLowerCase();
    const allowed = allowedEmails.length === 0 || allowedEmails.includes(email);
    callback({
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      allowed
    });
  });
}

export async function signInWithGoogle() {
  if (!auth) return null;
  const provider = new GoogleAuthProvider();
  return signInWithPopup(auth, provider);
}

export async function logout() {
  if (!auth) return;
  await signOut(auth);
}

function normalizeDoc(snapshot) {
  return { id: snapshot.id, ...snapshot.data() };
}

export async function getCollection(collectionName, sortField = 'sortOrder') {
  if (!db) return [];
  try {
    const ref = collection(db, collectionName);
    const snap = await getDocs(query(ref, orderBy(sortField, 'asc')));
    return snap.docs.map(normalizeDoc);
  } catch {
    const snap = await getDocs(collection(db, collectionName));
    return snap.docs.map(normalizeDoc);
  }
}

export async function getDocument(collectionName, id) {
  if (!db) return null;
  const snapshot = await getDoc(doc(db, collectionName, id));
  return snapshot.exists() ? normalizeDoc(snapshot) : null;
}

export async function createDocument(collectionName, payload) {
  if (!db) return null;
  const timestampFields = {};
  if (!payload.createdAt) timestampFields.createdAt = serverTimestamp();
  if (!payload.updatedAt) timestampFields.updatedAt = serverTimestamp();
  const ref = await addDoc(collection(db, collectionName), {
    ...payload,
    ...timestampFields
  });
  return ref.id;
}

export async function upsertDocument(collectionName, id, payload) {
  if (!db) return null;
  const timestampFields = {};
  if (!payload.updatedAt) timestampFields.updatedAt = serverTimestamp();
  await setDoc(
    doc(db, collectionName, id),
    {
      ...payload,
      ...timestampFields
    },
    { merge: true }
  );
  return id;
}

export async function patchDocument(collectionName, id, payload) {
  if (!db) return null;
  const timestampFields = {};
  if (!payload.updatedAt) timestampFields.updatedAt = serverTimestamp();
  await updateDoc(doc(db, collectionName, id), {
    ...payload,
    ...timestampFields
  });
}

export async function removeDocument(collectionName, id) {
  if (!db) return null;
  await deleteDoc(doc(db, collectionName, id));
}
