import { DEFAULT_ZONES } from '../data/zones.js';
import { SEED_PLANTS } from '../data/seedPlants.js';
import { makeId } from '../utils/idUtils.js';

const STORAGE_KEY = 'amaar-bagaan-v1';

const defaultState = {
  plants: SEED_PLANTS,
  deletedPlants: [],
  zones: DEFAULT_ZONES,
  careLogs: [],
  settings: {
    locationName: import.meta.env.VITE_GARDEN_LOCATION_NAME || 'Rakhajungle, Kharagpur',
    latitude: Number(import.meta.env.VITE_GARDEN_LAT || 22.3612),
    longitude: Number(import.meta.env.VITE_GARDEN_LON || 87.3576),
    languageMode: 'mixed',
    seedVersion: '1.3.5',
    lastSeededAt: null,
    lastMigratedAt: null
  },
  plantKnowledgeCache: [],
  meta: {
    schemaVersion: 4,
    appVersion: '1.3.5'
  }
};

function reviveState(state) {
  return {
    ...state,
    plants: Array.isArray(state.plants) ? state.plants : [],
    deletedPlants: Array.isArray(state.deletedPlants) ? state.deletedPlants : [],
    zones: Array.isArray(state.zones) ? state.zones : [],
    careLogs: Array.isArray(state.careLogs) ? state.careLogs : [],
    settings: { ...defaultState.settings, ...(state.settings || {}) },
    meta: { ...defaultState.meta, ...(state.meta || {}) }
  };
}

export function loadLocalState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(defaultState);
    return reviveState({ ...structuredClone(defaultState), ...JSON.parse(raw) });
  } catch (error) {
    console.warn('Failed to load Amaar Bagaan local state:', error);
    return structuredClone(defaultState);
  }
}

export function saveLocalState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function resetLocalState() {
  localStorage.removeItem(STORAGE_KEY);
  return loadLocalState();
}

export function makeCareLog(plantId, action, note = '', plant = null, timestamp = new Date().toISOString()) {
  return {
    id: makeId('log'),
    schemaVersion: 4,
    plantId,
    plantName: plant?.name || '',
    zoneId: plant?.zoneId || '',
    action,
    type: action,
    status: 'completed',
    note,
    source: 'manual',
    createdAt: timestamp,
    updatedAt: timestamp
  };
}
