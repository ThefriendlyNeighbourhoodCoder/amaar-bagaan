const WEATHER_CODE = {
  0: 'Clear sky',
  1: 'Mainly clear',
  2: 'Partly cloudy',
  3: 'Overcast',
  45: 'Fog',
  48: 'Depositing rime fog',
  51: 'Light drizzle',
  53: 'Moderate drizzle',
  55: 'Dense drizzle',
  61: 'Slight rain',
  63: 'Moderate rain',
  65: 'Heavy rain',
  80: 'Rain showers',
  81: 'Moderate showers',
  82: 'Violent showers',
  95: 'Thunderstorm'
};

export async function fetchWeather({ latitude, longitude }) {
  const lat = Number(latitude || 22.3612);
  const lon = Number(longitude || 87.3576);
  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.searchParams.set('latitude', lat.toString());
  url.searchParams.set('longitude', lon.toString());
  url.searchParams.set('current', 'temperature_2m,relative_humidity_2m,precipitation,rain,weather_code,wind_speed_10m');
  url.searchParams.set('hourly', 'temperature_2m,relative_humidity_2m,precipitation_probability');
  url.searchParams.set('daily', 'temperature_2m_max,temperature_2m_min,precipitation_probability_max');
  url.searchParams.set('timezone', 'auto');

  const response = await fetch(url.toString());
  if (!response.ok) throw new Error('Unable to fetch weather');
  const data = await response.json();
  const current = data.current || {};
  const todayRainProbability = data.daily?.precipitation_probability_max?.[0] ?? 0;

  return {
    temperature: Math.round(current.temperature_2m ?? 0),
    humidity: Math.round(current.relative_humidity_2m ?? 0),
    precipitation: Number(current.precipitation ?? current.rain ?? 0),
    rainProbability: todayRainProbability,
    windSpeed: Math.round(current.wind_speed_10m ?? 0),
    code: current.weather_code,
    condition: WEATHER_CODE[current.weather_code] || 'Weather update',
    high: Math.round(data.daily?.temperature_2m_max?.[0] ?? current.temperature_2m ?? 0),
    low: Math.round(data.daily?.temperature_2m_min?.[0] ?? current.temperature_2m ?? 0),
    fetchedAt: new Date().toISOString()
  };
}

export function getFallbackWeather() {
  return {
    temperature: 32,
    humidity: 70,
    precipitation: 0,
    rainProbability: 20,
    windSpeed: 8,
    code: 2,
    condition: 'Partly cloudy',
    high: 35,
    low: 26,
    fetchedAt: new Date().toISOString(),
    fallback: true
  };
}
