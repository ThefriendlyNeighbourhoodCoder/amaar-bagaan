import { slugify } from '../utils/idUtils.js';

const KNOWN_CARE = {
  tulsi: {
    scientificName: 'Ocimum tenuiflorum',
    category: 'Medicinal Herb',
    sunlight: 'full-sun',
    waterNeed: 'moderate',
    waterFrequencyDays: 1,
    fertilizerFrequencyDays: 30,
    soilType: 'Well-drained fertile soil',
    careDos: ['Keep in bright morning sunlight', 'Water when top soil feels dry', 'Pinch flower spikes for bushier growth'],
    careDonts: ['Do not keep soil soggy', 'Avoid full shade', 'Avoid afternoon watering during peak heat']
  },
  'holy-basil': {
    scientificName: 'Ocimum tenuiflorum',
    category: 'Medicinal Herb',
    sunlight: 'full-sun',
    waterNeed: 'moderate',
    waterFrequencyDays: 1,
    fertilizerFrequencyDays: 30,
    soilType: 'Well-drained fertile soil',
    careDos: ['Keep in bright morning sunlight', 'Water when top soil feels dry', 'Pinch flower spikes for bushier growth'],
    careDonts: ['Do not keep soil soggy', 'Avoid full shade', 'Avoid afternoon watering during peak heat']
  },
  'money-plant': {
    scientificName: 'Epipremnum aureum',
    category: 'Indoor Foliage',
    sunlight: 'bright-indirect-light',
    waterNeed: 'low-moderate',
    waterFrequencyDays: 5,
    fertilizerFrequencyDays: 45,
    soilType: 'Loose potting mix with drainage',
    careDos: ['Keep in bright indirect light', 'Let top soil dry before watering', 'Trim vines to keep growth full'],
    careDonts: ['Avoid harsh direct sun', 'Avoid daily watering indoors', 'Avoid standing water in saucer']
  },
  pothos: {
    scientificName: 'Epipremnum aureum',
    category: 'Indoor Foliage',
    sunlight: 'bright-indirect-light',
    waterNeed: 'low-moderate',
    waterFrequencyDays: 5,
    fertilizerFrequencyDays: 45,
    soilType: 'Loose potting mix with drainage',
    careDos: ['Keep in bright indirect light', 'Let top soil dry before watering', 'Trim vines to keep growth full'],
    careDonts: ['Avoid harsh direct sun', 'Avoid daily watering indoors', 'Avoid standing water in saucer']
  },
  'aloe-vera': {
    scientificName: 'Aloe vera',
    category: 'Succulent',
    sunlight: 'bright-sun',
    waterNeed: 'low',
    waterFrequencyDays: 8,
    fertilizerFrequencyDays: 60,
    soilType: 'Sandy, fast-draining soil',
    careDos: ['Water deeply but rarely', 'Use drainage-heavy soil', 'Keep in bright light'],
    careDonts: ['Do not water daily', 'Avoid water sitting in crown', 'Do not keep in wet soil after rain']
  },
  hibiscus: {
    scientificName: 'Hibiscus rosa-sinensis',
    category: 'Flowering Plant',
    sunlight: 'full-sun',
    waterNeed: 'moderate-high',
    waterFrequencyDays: 1,
    fertilizerFrequencyDays: 20,
    soilType: 'Rich, well-drained soil',
    careDos: ['Give strong sunlight', 'Feed during flowering season', 'Prune lightly after blooms'],
    careDonts: ['Do not let soil fully dry in summer', 'Avoid waterlogging', 'Avoid poor airflow around leaves']
  },
  rose: {
    scientificName: 'Rosa',
    category: 'Flowering Plant',
    sunlight: 'full-sun',
    waterNeed: 'moderate',
    waterFrequencyDays: 2,
    fertilizerFrequencyDays: 25,
    soilType: 'Rich loamy soil',
    careDos: ['Give at least 5-6 hours sunlight', 'Remove spent flowers', 'Water at soil level'],
    careDonts: ['Avoid wetting leaves at night', 'Do not crowd airflow', 'Avoid irregular watering in heat']
  },
  jasmine: {
    scientificName: 'Jasminum',
    category: 'Flowering Vine/Shrub',
    sunlight: 'partial-full-sun',
    waterNeed: 'moderate',
    waterFrequencyDays: 2,
    fertilizerFrequencyDays: 30,
    soilType: 'Well-drained garden soil',
    careDos: ['Give morning sun', 'Prune after flowering', 'Keep support for climbing types'],
    careDonts: ['Avoid overwatering', 'Do not keep in dark shade']
  },
  neem: {
    scientificName: 'Azadirachta indica',
    category: 'Tree',
    sunlight: 'full-sun',
    waterNeed: 'low-moderate',
    waterFrequencyDays: 4,
    fertilizerFrequencyDays: 60,
    soilType: 'Well-drained soil',
    careDos: ['Keep in sun', 'Water young plants regularly', 'Prune dry branches'],
    careDonts: ['Avoid waterlogged soil', 'Do not keep in small pot too long']
  },
  'curry-leaf': {
    scientificName: 'Murraya koenigii',
    category: 'Edible Herb/Shrub',
    sunlight: 'full-sun',
    waterNeed: 'moderate',
    waterFrequencyDays: 2,
    fertilizerFrequencyDays: 30,
    soilType: 'Well-drained fertile soil',
    careDos: ['Give sun and warmth', 'Pinch tips for branching', 'Feed lightly in growing season'],
    careDonts: ['Avoid waterlogging', 'Avoid cold wet soil']
  },
  'snake-plant': {
    scientificName: 'Dracaena trifasciata',
    category: 'Indoor Succulent Foliage',
    sunlight: 'bright-indirect-light',
    waterNeed: 'low',
    waterFrequencyDays: 10,
    fertilizerFrequencyDays: 60,
    soilType: 'Fast-draining potting mix',
    careDos: ['Let soil dry fully', 'Keep in bright indirect light', 'Use pot with drainage'],
    careDonts: ['Do not overwater', 'Avoid standing water']
  }
};

const TEMPLATE_LIBRARY = [
  { name: 'Succulent', match: ['aloe', 'cactus', 'succulent', 'jade', 'echeveria', 'haworthia'], care: { category: 'Succulent', sunlight: 'bright-sun', waterNeed: 'low', waterFrequencyDays: 8, fertilizerFrequencyDays: 60, soilType: 'Fast-draining sandy soil', careDos: ['Use well-draining soil', 'Water only after soil dries', 'Give bright light'], careDonts: ['Do not water daily', 'Avoid waterlogged soil'] } },
  { name: 'Flowering Plant', match: ['rose', 'hibiscus', 'jasmine', 'flower', 'marigold', 'bougainvillea', 'gardenia'], care: { category: 'Flowering Plant', sunlight: 'full-sun', waterNeed: 'moderate', waterFrequencyDays: 2, fertilizerFrequencyDays: 30, soilType: 'Fertile well-drained soil', careDos: ['Give good sunlight', 'Remove dry flowers/leaves', 'Feed during growing season'], careDonts: ['Avoid stagnant water', 'Avoid poor airflow'] } },
  { name: 'Indoor Foliage', match: ['pothos', 'money plant', 'philodendron', 'palm', 'syngonium', 'aglaonema', 'monstera'], care: { category: 'Indoor Foliage', sunlight: 'bright-indirect-light', waterNeed: 'low-moderate', waterFrequencyDays: 5, fertilizerFrequencyDays: 45, soilType: 'Loose potting mix', careDos: ['Keep in indirect light', 'Check soil before watering', 'Wipe dusty leaves'], careDonts: ['Avoid harsh direct sun', 'Do not overwater indoors'] } },
  { name: 'Herb or Medicinal Plant', match: ['basil', 'tulsi', 'mint', 'coriander', 'curry', 'herb', 'medicinal'], care: { category: 'Herb / Medicinal', sunlight: 'morning-full-sun', waterNeed: 'moderate', waterFrequencyDays: 1, fertilizerFrequencyDays: 30, soilType: 'Fertile well-drained soil', careDos: ['Keep in morning sun', 'Harvest lightly to promote branching', 'Check soil daily in heat'], careDonts: ['Avoid soggy soil', 'Avoid deep shade'] } },
  { name: 'Tree or Shrub', match: ['neem', 'mango', 'guava', 'tree', 'shrub', 'ficus'], care: { category: 'Tree / Shrub', sunlight: 'full-sun', waterNeed: 'moderate', waterFrequencyDays: 3, fertilizerFrequencyDays: 45, soilType: 'Deep well-drained soil', careDos: ['Keep in open light', 'Prune dry branches', 'Water young plants regularly'], careDonts: ['Avoid root waterlogging', 'Do not keep root-bound too long'] } }
];

function inferCare(query, title = '', description = '') {
  const key = slugify(query);
  const titleKey = slugify(title);
  const known = KNOWN_CARE[key] || KNOWN_CARE[titleKey];
  if (known) return { ...known, templateName: 'Known plant match' };
  const text = `${query} ${title} ${description}`.toLowerCase();
  const template = TEMPLATE_LIBRARY.find((item) => item.match.some((token) => text.includes(token)));
  if (template) return { ...template.care, templateName: template.name };
  return { templateName: 'General care fallback', category: 'General Plant', sunlight: 'partial-sun', waterNeed: 'moderate', waterFrequencyDays: 3, fertilizerFrequencyDays: 45, soilType: 'Well-drained potting soil', careDos: ['Check soil before watering', 'Give suitable light', 'Remove dry or diseased leaves'], careDonts: ['Avoid overwatering', 'Avoid sudden location changes'] };
}

async function wikiSearch(query) {
  const url = new URL('https://en.wikipedia.org/w/api.php');
  url.searchParams.set('action', 'query');
  url.searchParams.set('list', 'search');
  url.searchParams.set('srsearch', `${query} plant`);
  url.searchParams.set('format', 'json');
  url.searchParams.set('origin', '*');
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error('Wikipedia search failed');
  const data = await response.json();
  return data.query?.search?.slice(0, 5) || [];
}

async function wikiSummary(title) {
  const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Wikipedia summary failed');
  return response.json();
}

async function wikidataSearch(query) {
  const url = new URL('https://www.wikidata.org/w/api.php');
  url.searchParams.set('action', 'wbsearchentities');
  url.searchParams.set('search', query);
  url.searchParams.set('language', 'en');
  url.searchParams.set('format', 'json');
  url.searchParams.set('origin', '*');
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error('Wikidata search failed');
  const data = await response.json();
  return data.search?.slice(0, 5) || [];
}

async function wikidataEntity(id) {
  if (!id) return null;
  const url = new URL('https://www.wikidata.org/w/api.php');
  url.searchParams.set('action', 'wbgetentities');
  url.searchParams.set('ids', id);
  url.searchParams.set('props', 'claims|labels|descriptions|sitelinks');
  url.searchParams.set('languages', 'en|bn');
  url.searchParams.set('format', 'json');
  url.searchParams.set('origin', '*');
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error('Wikidata entity fetch failed');
  const data = await response.json();
  return data.entities?.[id] || null;
}

function imageUrlFromCommonsFile(fileName) {
  if (!fileName) return '';
  const clean = String(fileName).replace(/^File:/i, '').replace(/ /g, '_');
  return `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(clean)}?width=800`;
}

function extractScientificName(entity, fallback) {
  const taxonName = entity?.claims?.P225?.[0]?.mainsnak?.datavalue?.value;
  return typeof taxonName === 'string' ? taxonName : fallback || '';
}

function extractCommonsImage(entity) {
  const image = entity?.claims?.P18?.[0]?.mainsnak?.datavalue?.value;
  return typeof image === 'string' ? imageUrlFromCommonsFile(image) : '';
}

function confidenceScore({ query, summary, entity, care, matches }) {
  let score = 42;
  const normalizedQuery = query.toLowerCase();
  const title = summary?.title?.toLowerCase() || '';
  if (title && (title.includes(normalizedQuery) || normalizedQuery.includes(title))) score += 18;
  if (entity) score += 16;
  if (extractScientificName(entity, care.scientificName)) score += 10;
  if (summary?.extract) score += 7;
  if (summary?.thumbnail?.source || extractCommonsImage(entity)) score += 7;
  if (care.templateName === 'Known plant match') score += 10;
  if ((matches || []).length === 0) score -= 8;
  return Math.max(20, Math.min(98, score));
}

function stripHtmlSnippet(snippet = '') {
  return snippet.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
}

function buildProfile({ query, summary, entity, care, wikidataMatches, sourceNote }) {
  const scientificName = extractScientificName(entity, care.scientificName);
  const bengaliName = entity?.labels?.bn?.value || '';
  const wikidataImage = extractCommonsImage(entity);
  const summaryImage = summary?.thumbnail?.source || summary?.originalimage?.source || '';
  const imageUrl = wikidataImage || summaryImage || '';
  const confidence = confidenceScore({ query, summary, entity, care, matches: wikidataMatches });
  return {
    id: `plant-${slugify(query)}-${Date.now()}`,
    name: query,
    localName: bengaliName,
    scientificName,
    category: care.category,
    zoneId: 'roof-east',
    indoorOutdoor: care.category?.toLowerCase().includes('indoor') ? 'indoor' : 'outdoor',
    sunlight: care.sunlight,
    waterNeed: care.waterNeed,
    waterFrequencyDays: care.waterFrequencyDays,
    fertilizerFrequencyDays: care.fertilizerFrequencyDays,
    soilType: care.soilType,
    imageUrl,
    imageSource: imageUrl ? (wikidataImage ? 'Wikidata / Wikimedia Commons' : 'Wikipedia / Wikimedia') : 'Care template fallback',
    sourceUrl: summary?.content_urls?.desktop?.page || (entity?.id ? `https://www.wikidata.org/wiki/${entity.id}` : ''),
    knowledgeSources: [summary?.content_urls?.desktop?.page && { label: 'Wikipedia', url: summary.content_urls.desktop.page }, entity?.id && { label: 'Wikidata', url: `https://www.wikidata.org/wiki/${entity.id}` }, imageUrl && { label: wikidataImage ? 'Wikimedia Commons image' : 'Wikipedia reference image', url: imageUrl }].filter(Boolean),
    confidence,
    confidenceLabel: confidence >= 82 ? 'Strong match' : confidence >= 62 ? 'Good draft' : 'Review carefully',
    sourceGenerated: true,
    verifiedByUser: false,
    careTemplateName: care.templateName || 'Care template',
    sourceNote,
    summary: summary?.extract || entity?.descriptions?.en?.value || `${query} profile created from Amaar Bagaan smart care template. Review sunlight, watering and zone before saving.`,
    careDos: care.careDos,
    careDonts: care.careDonts,
    lastWateredAt: null,
    lastFertilizedAt: null
  };
}

export async function enrichPlantByName(queryText) {
  const query = queryText.trim();
  if (!query) throw new Error('Enter a plant name first');
  const errors = [];
  let matches = [];
  try { matches = await wikiSearch(query); } catch (error) { errors.push('Wikipedia search unavailable'); console.warn(error); }
  const firstTitle = matches[0]?.title || query;
  let summary = null;
  try { summary = await wikiSummary(firstTitle); } catch (error) { errors.push('Wikipedia summary unavailable'); console.warn(error); }
  let wikidataMatches = [];
  try { wikidataMatches = await wikidataSearch(summary?.title || query); } catch (error) { errors.push('Wikidata lookup unavailable'); console.warn(error); }
  let entity = null;
  try { entity = await wikidataEntity(wikidataMatches[0]?.id); } catch (error) { errors.push('Wikidata entity unavailable'); console.warn(error); }
  const description = `${summary?.extract || ''} ${entity?.descriptions?.en?.value || ''}`;
  const care = inferCare(query, summary?.title || firstTitle, description);
  const profile = buildProfile({ query, summary, entity, care, wikidataMatches, sourceNote: errors.length ? `Fallbacks used: ${errors.join(', ')}` : 'Wikipedia/Wikidata enriched profile with care-template fallback.' });
  const candidates = matches.map((match, index) => ({ id: `wiki-${index}`, title: match.title, snippet: stripHtmlSnippet(match.snippet || ''), source: 'Wikipedia' })).concat(wikidataMatches.map((match, index) => ({ id: match.id || `wikidata-${index}`, title: match.label || match.id, snippet: match.description || '', source: 'Wikidata' })));
  return { query, matches: candidates.slice(0, 8), profile, sourceHealth: { wikipedia: Boolean(summary), wikidata: Boolean(entity), image: Boolean(profile.imageUrl), fallbackCare: true, errors } };
}
