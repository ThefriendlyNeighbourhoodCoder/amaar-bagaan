import { daysBetween } from '../utils/dateUtils.js';

function zoneForPlant(plant, zones) {
  return zones.find((zone) => zone.id === plant.zoneId);
}

function dueStatus(lastDate, frequencyDays) {
  if (!frequencyDays) return { due: false, days: 0, overdue: false };
  const days = daysBetween(lastDate);
  if (days === Infinity) return { due: true, days: Infinity, overdue: true };
  return { due: days >= frequencyDays, days, overdue: days > frequencyDays };
}

export function zoneRisk(zone, zonePlants = [], zoneTasks = [], weather) {
  if (!zone) return { level: 'normal', label: 'Balanced', reasons: [] };
  const reasons = [];
  let score = zoneTasks.length > 0 ? 1 : 0;

  if (weather?.temperature >= 36 && zone.heatRisk === 'high') {
    score += 3;
    reasons.push('High heat exposure');
  } else if (weather?.temperature >= 34 && ['high', 'medium'].includes(zone.heatRisk)) {
    score += 2;
    reasons.push('Warm zone today');
  }

  if (weather?.rainProbability >= 60 && ['high', 'medium'].includes(zone.rainExposure)) {
    score += 2;
    reasons.push('Rain exposure likely');
  }

  if (weather?.windSpeed >= 24 && ['high', 'medium'].includes(zone.windRisk)) {
    score += 2;
    reasons.push('Wind edge caution');
  }

  if (zonePlants.length === 0) return { level: 'empty', label: 'No plants', reasons: ['No plants placed in this zone'] };
  if (score >= 4) return { level: 'high', label: 'High watch', reasons };
  if (score >= 2) return { level: 'watch', label: 'Watch', reasons };
  if (zoneTasks.length > 0) return { level: 'due', label: 'Care due', reasons: ['Scheduled care pending'] };
  return { level: 'normal', label: 'Balanced', reasons: reasons.length ? reasons : ['Normal care rhythm'] };
}

export function buildCareTasks(plants, zones, weather) {
  const tasks = [];
  plants.forEach((plant) => {
    const zone = zoneForPlant(plant, zones);
    const watering = dueStatus(plant.lastWateredAt, Number(plant.waterFrequencyDays || 0));
    const fertilizer = dueStatus(plant.lastFertilizedAt, Number(plant.fertilizerFrequencyDays || 0));
    const isSucculent = plant.category?.toLowerCase().includes('succulent');
    const isOutdoor = plant.indoorOutdoor === 'outdoor';
    const zoneHeat = weather?.temperature >= 35 && ['roof', 'boundary', 'outdoor'].includes(zone?.type);
    const rainLikely = weather?.rainProbability >= 55 && isOutdoor;

    if (watering.due) {
      let priority = watering.overdue ? 'high' : 'normal';
      let guidance = 'Check top soil first, then water gently at the base.';

      if (rainLikely) {
        priority = 'watch';
        guidance = 'Rain is likely. Check soil first and skip watering if the pot is moist.';
      }
      if (zoneHeat) {
        priority = watering.overdue ? 'high' : 'watch';
        guidance = 'Heat exposure is high. Water only morning/evening; avoid afternoon shock.';
      }
      if (isSucculent) {
        priority = weather?.rainProbability >= 40 ? 'watch' : priority;
        guidance = 'Succulent profile. Water only if soil is fully dry.';
      }
      if (plant.waterNeed?.includes('high') && weather?.temperature >= 34 && !rainLikely) {
        priority = 'high';
        guidance = 'High-water plant under heat. Check soil moisture early today.';
      }

      tasks.push({ id: `water-${plant.id}`, plantId: plant.id, plantName: plant.name, zoneId: zone?.id || '', zoneName: zone?.name || 'Unassigned', type: 'watered', title: `Water ${plant.name}`, priority, guidance, weatherLinked: rainLikely || zoneHeat });
    }

    if (fertilizer.due) {
      const hotOrRainy = weather?.temperature >= 36 || weather?.rainProbability >= 60;
      tasks.push({ id: `fertilizer-${plant.id}`, plantId: plant.id, plantName: plant.name, zoneId: zone?.id || '', zoneName: zone?.name || 'Unassigned', type: 'fertilized', title: `Fertilize ${plant.name}`, priority: fertilizer.overdue ? 'high' : hotOrRainy ? 'watch' : 'normal', guidance: hotOrRainy ? 'Weather is not ideal. Use mild dose only if soil is stable.' : 'Use a mild dose and water lightly after feeding.', weatherLinked: hotOrRainy });
    }
  });

  return tasks.sort((a, b) => {
    const order = { high: 0, watch: 1, due: 2, normal: 3 };
    return order[a.priority] - order[b.priority];
  });
}

export function buildWeatherAdvice(plants, zones, weather) {
  const advice = [];
  const roofPlants = plants.filter((plant) => zoneForPlant(plant, zones)?.type === 'roof');
  const boundaryPlants = plants.filter((plant) => zoneForPlant(plant, zones)?.type === 'boundary');
  const outdoorPlants = plants.filter((plant) => plant.indoorOutdoor === 'outdoor');
  const indoorPlants = plants.filter((plant) => plant.indoorOutdoor === 'indoor');
  const succulentPlants = plants.filter((plant) => `${plant.category} ${plant.name}`.toLowerCase().includes('succulent') || `${plant.name}`.toLowerCase().includes('aloe'));
  const floweringPlants = plants.filter((plant) => `${plant.category} ${plant.name}`.toLowerCase().includes('flower') || ['rose', 'hibiscus', 'jasmine', 'bougainvillea'].some((name) => plant.name?.toLowerCase().includes(name)));

  if (!weather) return advice;

  if (weather.temperature >= 37) {
    advice.push({
      level: 'high',
      title: 'Extreme heat protection',
      text: `${roofPlants.length + boundaryPlants.length} exposed plants need early-morning or late-evening checks. Avoid afternoon watering shock.`,
      bn: 'দুপুরে জল দেবেন না। সকাল বা সন্ধ্যায় মাটি দেখে জল দিন।'
    });
  } else if (weather.temperature >= 34) {
    advice.push({
      level: 'watch',
      title: 'Warm day soil check',
      text: 'Small pots can dry quickly. Touch the top soil before watering, especially roof and west-side pots.',
      bn: 'ছোট টব আগে দেখুন। উপরিভাগ শুকনো হলে তবেই জল দিন।'
    });
  }

  if (weather.high - weather.low >= 9) {
    advice.push({
      level: 'watch',
      title: 'Temperature swing today',
      text: 'Large day-night temperature change can stress tender leaves. Avoid repotting, hard pruning, or fertilizer shock today.',
      bn: 'আজ গাছ না সরানো, না ছাঁটা, আর বেশি সার না দেওয়াই ভালো।'
    });
  }

  if (weather.rainProbability >= 75) {
    advice.push({
      level: 'high',
      title: 'Heavy rain watch',
      text: `Skip routine outdoor watering. Check drainage holes and move ${succulentPlants.length || 'succulent'} pots away from standing water.`,
      bn: 'বাইরের টবে জল জমছে কি না দেখুন। সাকুলেন্ট ভিজিয়ে রাখবেন না।'
    });
  } else if (weather.rainProbability >= 55) {
    advice.push({
      level: 'watch',
      title: 'Rain likely today',
      text: `Outdoor plants may not need extra watering. Check soil before watering ${outdoorPlants.length} outdoor plants.`,
      bn: 'বৃষ্টি হলে বাইরের গাছে অতিরিক্ত জল দেবেন না। আগে মাটি ছুঁয়ে দেখুন।'
    });
  }

  if (weather.humidity >= 88) {
    advice.push({
      level: 'watch',
      title: 'High humidity leaf check',
      text: `${floweringPlants.length} flowering or dense plants may need airflow. Remove fallen leaves and avoid wetting foliage late evening.`,
      bn: 'পাতায় জল আটকে রাখবেন না। শুকনো পাতা সরিয়ে বাতাস চলাচল রাখুন।'
    });
  } else if (weather.humidity <= 45 && indoorPlants.length > 0) {
    advice.push({
      level: 'normal',
      title: 'Dry air for indoor plants',
      text: 'Indoor foliage may appreciate light misting. Avoid misting succulents or plants sitting in low light.',
      bn: 'ইনডোর পাতাবাহার গাছে হালকা মিস্ট করা যায়, তবে অ্যালোভেরা নয়।'
    });
  }

  if (weather.windSpeed >= 28) {
    advice.push({
      level: 'high',
      title: 'Strong wind caution',
      text: 'Secure lightweight roof and boundary pots. Move tall plants away from exposed edges.',
      bn: 'হালকা টব ছাদের ধারে রাখবেন না। লম্বা গাছ নিরাপদে সরান।'
    });
  } else if (weather.windSpeed >= 20) {
    advice.push({
      level: 'watch',
      title: 'Breezy roof/boundary check',
      text: 'Check hanging, tall, or recently moved pots near roof and boundary edges.',
      bn: 'ঝুলন্ত বা লম্বা টব ঠিক আছে কি না দেখে নিন।'
    });
  }

  if (weather.condition?.toLowerCase().includes('overcast') || weather.condition?.toLowerCase().includes('cloud')) {
    advice.push({
      level: 'normal',
      title: 'Overcast light adjustment',
      text: 'Shade-loving plants are comfortable. Sun-loving plants may not need movement unless soil stays wet.',
      bn: 'মেঘলা দিনে আলো কম থাকে, তাই অযথা টব সরানোর দরকার নেই।'
    });
  }

  if (advice.length === 0) {
    advice.push({
      level: 'normal',
      title: 'Balanced care day',
      text: 'Weather looks manageable. Follow normal watering schedule and check leaves visually.',
      bn: 'আজ সাধারণ যত্নই যথেষ্ট। পাতা আর মাটি দেখে নিন।'
    });
  }

  return advice.slice(0, 5);
}
export function gardenSummary(plants, tasks) {
  const high = tasks.filter((task) => task.priority === 'high').length;
  const watch = tasks.filter((task) => task.priority === 'watch').length;
  return { totalPlants: plants.length, dueToday: tasks.length, highPriority: high, watchCount: watch, healthyCount: Math.max(plants.length - tasks.length, 0) };
}
