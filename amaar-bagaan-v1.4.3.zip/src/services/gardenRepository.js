import { DEFAULT_ZONES } from '../data/zones.js';
import { SEED_PLANTS } from '../data/seedPlants.js';
import { makeId } from '../utils/idUtils.js';
import { toIso } from '../utils/dateUtils.js';
import { loadLocalState, saveLocalState, makeCareLog } from './localStore.js';
import { hasFirebaseConfig, getCollection, getDocument, upsertDocument, patchDocument, removeDocument } from './firebaseClient.js';

const SCHEMA_VERSION = 4;
const SEED_VERSION = '1.3.5';

function nowIso() {
  return new Date().toISOString();
}

function asNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

export function normalizePlant(plant = {}, source = 'existing') {
  const timestamp = toIso(plant.createdAt) || nowIso();
  const updatedAt = toIso(plant.updatedAt) || timestamp;
  const id = plant.id || makeId('plant');
  return {
    ...plant,
    id,
    schemaVersion: SCHEMA_VERSION,
    name: String(plant.name || 'Unnamed plant').trim(),
    localName: plant.localName || '',
    scientificName: plant.scientificName || '',
    category: plant.category || 'General Plant',
    zoneId: plant.zoneId || 'roof-east',
    indoorOutdoor: plant.indoorOutdoor || 'outdoor',
    sunlight: plant.sunlight || plant.careProfile?.sunlight || 'partial-sun',
    waterNeed: plant.waterNeed || plant.careProfile?.waterNeed || 'moderate',
    waterFrequencyDays: asNumber(plant.waterFrequencyDays ?? plant.careProfile?.waterFrequencyDays, 3),
    fertilizerFrequencyDays: asNumber(plant.fertilizerFrequencyDays ?? plant.careProfile?.fertilizerFrequencyDays, 45),
    soilType: plant.soilType || plant.careProfile?.soilType || 'Well-drained potting soil',
    imageUrl: plant.imageUrl || '',
    imageSource: plant.imageSource || 'Manual',
    sourceUrl: plant.sourceUrl || '',
    knowledgeSources: Array.isArray(plant.knowledgeSources) ? plant.knowledgeSources : [],
    confidence: asNumber(plant.confidence, plant.sourceGenerated ? 55 : 100),
    confidenceLabel: plant.confidenceLabel || (plant.sourceGenerated ? 'Review carefully' : 'Verified manually'),
    careTemplateName: plant.careTemplateName || '',
    sourceNote: plant.sourceNote || '',
    summary: plant.summary || '',
    careDos: Array.isArray(plant.careDos) ? plant.careDos : [],
    careDonts: Array.isArray(plant.careDonts) ? plant.careDonts : [],
    lastWateredAt: toIso(plant.lastWateredAt),
    lastFertilizedAt: toIso(plant.lastFertilizedAt),
    deletedAt: toIso(plant.deletedAt),
    status: plant.deletedAt ? 'deleted' : plant.status || 'active',
    lifecycle: {
      createdFrom: plant.lifecycle?.createdFrom || (plant.sourceGenerated ? 'smart-add' : source),
      verifiedByUser: plant.verifiedByUser ?? plant.lifecycle?.verifiedByUser ?? true,
      sourceGenerated: plant.sourceGenerated ?? plant.lifecycle?.sourceGenerated ?? false
    },
    careProfile: {
      sunlight: plant.sunlight || plant.careProfile?.sunlight || 'partial-sun',
      waterNeed: plant.waterNeed || plant.careProfile?.waterNeed || 'moderate',
      waterFrequencyDays: asNumber(plant.waterFrequencyDays ?? plant.careProfile?.waterFrequencyDays, 3),
      fertilizerFrequencyDays: asNumber(plant.fertilizerFrequencyDays ?? plant.careProfile?.fertilizerFrequencyDays, 45),
      soilType: plant.soilType || plant.careProfile?.soilType || 'Well-drained potting soil'
    },
    createdAt: timestamp,
    updatedAt
  };
}

function normalizeZone(zone = {}) {
  const defaultZone = DEFAULT_ZONES.find((item) => item.id === zone.id) || {};
  const merged = { ...defaultZone, ...zone };
  return {
    ...merged,
    id: merged.id || makeId('zone'),
    name: merged.name || 'New garden area',
    banglaName: merged.banglaName || '',
    type: merged.type || 'custom',
    sunlightProfile: merged.sunlightProfile || 'mixed-light',
    heatRisk: merged.heatRisk || 'medium',
    rainExposure: merged.rainExposure || 'medium',
    windRisk: merged.windRisk || 'medium',
    humidityProfile: merged.humidityProfile || 'normal',
    airflow: merged.airflow || 'moderate',
    shadeLevel: merged.shadeLevel || 'partial-shade',
    description: merged.description || 'Custom area created for Amaar Bagaan.',
    schemaVersion: SCHEMA_VERSION,
    sortOrder: asNumber(merged.sortOrder, 99),
    map: merged.map || defaultZone.map || { x: 48, y: 88, w: 24, h: 10 },
    createdAt: toIso(merged.createdAt) || nowIso(),
    updatedAt: toIso(merged.updatedAt) || toIso(merged.createdAt) || nowIso()
  };
}

function normalizeCareLog(log = {}, plants = [], zones = []) {
  const plant = plants.find((item) => item.id === log.plantId);
  const zone = zones.find((item) => item.id === (log.zoneId || plant?.zoneId));
  const timestamp = toIso(log.createdAt) || nowIso();
  return {
    ...log,
    id: log.id || makeId('log'),
    schemaVersion: SCHEMA_VERSION,
    plantId: log.plantId || '',
    plantName: log.plantName || plant?.name || '',
    zoneId: log.zoneId || plant?.zoneId || '',
    zoneName: log.zoneName || zone?.name || '',
    action: log.action || log.type || 'note',
    type: log.type || log.action || 'note',
    status: log.status || 'completed',
    note: log.note || '',
    source: log.source || 'manual',
    createdAt: timestamp,
    updatedAt: toIso(log.updatedAt) || timestamp
  };
}

function normalizeSettings(settings = {}) {
  return {
    locationName: settings.locationName || import.meta.env.VITE_GARDEN_LOCATION_NAME || 'Rakhajungle, Kharagpur',
    latitude: asNumber(settings.latitude ?? import.meta.env.VITE_GARDEN_LAT, 22.3612),
    longitude: asNumber(settings.longitude ?? import.meta.env.VITE_GARDEN_LON, 87.3576),
    languageMode: settings.languageMode || 'mixed',
    seedVersion: settings.seedVersion || null,
    lastSeededAt: toIso(settings.lastSeededAt),
    lastMigratedAt: toIso(settings.lastMigratedAt)
  };
}

export function migrateGardenState(inputState) {
  const zones = (inputState.zones?.length ? inputState.zones : DEFAULT_ZONES).map(normalizeZone).sort((a, b) => a.sortOrder - b.sortOrder);
  const allPlants = (inputState.plants?.length ? inputState.plants : SEED_PLANTS).map((plant) => normalizePlant(plant));
  const activePlants = allPlants.filter((plant) => !plant.deletedAt && plant.status !== 'deleted');
  const deletedPlants = [
    ...(inputState.deletedPlants || []),
    ...allPlants.filter((plant) => plant.deletedAt || plant.status === 'deleted')
  ].map((plant) => normalizePlant(plant));
  const careLogs = (inputState.careLogs || [])
    .map((log) => normalizeCareLog(log, [...activePlants, ...deletedPlants], zones))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return {
    ...inputState,
    plants: activePlants,
    deletedPlants,
    zones,
    careLogs,
    settings: normalizeSettings(inputState.settings),
    meta: {
      ...(inputState.meta || {}),
      schemaVersion: SCHEMA_VERSION,
      appVersion: '1.3.1',
      migratedAt: nowIso()
    }
  };
}

async function persistFullState(state) {
  saveLocalState(state);
  if (!hasFirebaseConfig) return;
  await Promise.all([
    ...state.zones.map((zone) => upsertDocument('zones', zone.id, zone)),
    ...state.plants.map((plant) => upsertDocument('plants', plant.id, plant)),
    ...state.deletedPlants.map((plant) => upsertDocument('plants', plant.id, plant)),
    ...state.careLogs.map((log) => upsertDocument('careLogs', log.id, log)),
    upsertDocument('settings', 'garden', state.settings)
  ]);
}

export async function loadGardenState() {
  const local = migrateGardenState(loadLocalState());
  if (!hasFirebaseConfig) return { ...local, source: 'local' };

  try {
    const [remotePlants, remoteZones, remoteLogs, remoteSettings] = await Promise.all([
      getCollection('plants', 'name'),
      getCollection('zones', 'sortOrder'),
      getCollection('careLogs', 'createdAt'),
      getDocument('settings', 'garden')
    ]);

    const remoteState = migrateGardenState({
      ...local,
      plants: remotePlants.length ? remotePlants : local.plants,
      zones: remoteZones.length ? remoteZones : local.zones,
      careLogs: remoteLogs.length ? remoteLogs : local.careLogs,
      settings: remoteSettings ? { ...local.settings, ...remoteSettings } : local.settings
    });
    const next = { ...remoteState, source: 'firebase' };
    saveLocalState(next);
    return next;
  } catch (error) {
    console.warn('Firestore read failed. Using local garden cache until rules/config are ready.', error);
    return { ...local, source: 'local', firebaseError: error?.message || 'Firestore unavailable' };
  }
}

export async function seedFirebaseIfEmpty() {
  if (!hasFirebaseConfig) return false;
  const [plants, zones, settings] = await Promise.all([getCollection('plants', 'name'), getCollection('zones', 'sortOrder'), getDocument('settings', 'garden')]);
  const plantIds = new Set(plants.map((plant) => plant.id));
  const zoneIds = new Set(zones.map((zone) => zone.id));
  const missingZones = DEFAULT_ZONES.filter((zone) => !zoneIds.has(zone.id)).map(normalizeZone);
  const missingPlants = SEED_PLANTS.filter((plant) => !plantIds.has(plant.id)).map((plant) => normalizePlant(plant, 'seed'));
  const shouldUpdateSettings = !settings || settings.seedVersion !== SEED_VERSION;
  const timestamp = nowIso();

  await Promise.all([
    ...missingZones.map((zone) => upsertDocument('zones', zone.id, zone)),
    ...missingPlants.map((plant) => upsertDocument('plants', plant.id, plant)),
    shouldUpdateSettings
      ? upsertDocument('settings', 'garden', {
          ...normalizeSettings(settings || loadLocalState().settings),
          seedVersion: SEED_VERSION,
          lastSeededAt: timestamp,
          updatedAt: timestamp
        })
      : Promise.resolve()
  ]);
  return missingPlants.length > 0 || missingZones.length > 0 || shouldUpdateSettings;
}

export async function savePlant(state, plant) {
  const timestamp = nowIso();
  const payload = normalizePlant({ ...plant, updatedAt: timestamp, createdAt: plant.createdAt || timestamp });

  const next = migrateGardenState({
    ...state,
    plants: state.plants.some((item) => item.id === payload.id)
      ? state.plants.map((item) => (item.id === payload.id ? payload : item))
      : [payload, ...state.plants]
  });
  saveLocalState(next);

  if (hasFirebaseConfig) await upsertDocument('plants', payload.id, payload);
  return next;
}

export async function deletePlant(state, plantId) {
  const timestamp = nowIso();
  const plant = state.plants.find((item) => item.id === plantId);
  if (!plant) return state;
  const deletedPlant = normalizePlant({ ...plant, status: 'deleted', deletedAt: timestamp, updatedAt: timestamp });
  const next = migrateGardenState({
    ...state,
    plants: state.plants.filter((item) => item.id !== plantId),
    deletedPlants: [deletedPlant, ...(state.deletedPlants || [])]
  });
  saveLocalState(next);
  if (hasFirebaseConfig) await upsertDocument('plants', plantId, deletedPlant);
  return next;
}

export async function restorePlant(state, plantId) {
  const timestamp = nowIso();
  const plant = state.deletedPlants?.find((item) => item.id === plantId);
  if (!plant) return state;
  const restored = normalizePlant({ ...plant, status: 'active', deletedAt: null, updatedAt: timestamp });
  const next = migrateGardenState({
    ...state,
    plants: [restored, ...state.plants],
    deletedPlants: state.deletedPlants.filter((item) => item.id !== plantId)
  });
  saveLocalState(next);
  if (hasFirebaseConfig) await upsertDocument('plants', restored.id, restored);
  return next;
}

export async function recordCareAction(state, plantId, action, note = '') {
  const timestamp = nowIso();
  const plant = state.plants.find((item) => item.id === plantId);
  const zone = state.zones.find((item) => item.id === plant?.zoneId);
  const log = {
    ...makeCareLog(plantId, action, note, plant, timestamp),
    zoneName: zone?.name || ''
  };
  const plantPatch =
    action === 'watered'
      ? { lastWateredAt: timestamp }
      : action === 'fertilized'
        ? { lastFertilizedAt: timestamp }
        : {};

  const next = migrateGardenState({
    ...state,
    plants: state.plants.map((item) => (item.id === plantId ? { ...item, ...plantPatch, updatedAt: timestamp } : item)),
    careLogs: [log, ...state.careLogs]
  });
  saveLocalState(next);

  if (hasFirebaseConfig) {
    await upsertDocument('careLogs', log.id, log);
    if (Object.keys(plantPatch).length) await patchDocument('plants', plantId, { ...plantPatch, updatedAt: timestamp });
  }
  return next;
}


export async function saveZone(state, zone) {
  const timestamp = nowIso();
  const nextZone = normalizeZone({
    ...zone,
    id: zone.id || makeId('zone'),
    sortOrder: asNumber(zone.sortOrder, state.zones.length + 1),
    updatedAt: timestamp,
    createdAt: zone.createdAt || timestamp
  });
  const next = migrateGardenState({
    ...state,
    zones: state.zones.some((item) => item.id === nextZone.id)
      ? state.zones.map((item) => (item.id === nextZone.id ? nextZone : item))
      : [...state.zones, nextZone]
  });
  saveLocalState(next);
  if (hasFirebaseConfig) await upsertDocument('zones', nextZone.id, nextZone);
  return next;
}

export async function deleteZone(state, zoneId) {
  const timestamp = nowIso();
  const zone = state.zones.find((item) => item.id === zoneId);
  if (!zone || state.zones.length <= 1) return state;
  const fallbackZone = state.zones.find((item) => item.id !== zoneId)?.id || 'roof-east';
  const touchedPlants = state.plants
    .filter((plant) => plant.zoneId === zoneId)
    .map((plant) => normalizePlant({ ...plant, zoneId: fallbackZone, updatedAt: timestamp }));
  const next = migrateGardenState({
    ...state,
    zones: state.zones.filter((item) => item.id !== zoneId),
    plants: state.plants.map((plant) =>
      plant.zoneId === zoneId ? { ...plant, zoneId: fallbackZone, updatedAt: timestamp } : plant
    )
  });
  saveLocalState(next);
  if (hasFirebaseConfig) {
    await removeDocument('zones', zoneId);
    await Promise.all(touchedPlants.map((plant) => upsertDocument('plants', plant.id, plant)));
  }
  return next;
}

export async function updateSettings(state, settings) {
  const timestamp = nowIso();
  const next = migrateGardenState({ ...state, settings: { ...state.settings, ...settings, updatedAt: timestamp } });
  saveLocalState(next);
  if (hasFirebaseConfig) await upsertDocument('settings', 'garden', next.settings);
  return next;
}

export async function migrateAndPersistState(state) {
  const next = migrateGardenState({ ...state, settings: { ...state.settings, lastMigratedAt: nowIso() } });
  await persistFullState(next);
  return next;
}

export async function reseedMissingData(state) {
  const timestamp = nowIso();
  const plantIds = new Set(state.plants.map((plant) => plant.id));
  const zoneIds = new Set(state.zones.map((zone) => zone.id));
  const missingPlants = SEED_PLANTS.filter((plant) => !plantIds.has(plant.id)).map((plant) => normalizePlant({ ...plant, updatedAt: timestamp }, 'seed'));
  const missingZones = DEFAULT_ZONES.filter((zone) => !zoneIds.has(zone.id)).map(normalizeZone);
  const next = migrateGardenState({
    ...state,
    plants: [...missingPlants, ...state.plants],
    zones: [...state.zones, ...missingZones].sort((a, b) => a.sortOrder - b.sortOrder),
    settings: { ...state.settings, seedVersion: SEED_VERSION, lastSeededAt: timestamp }
  });
  await persistFullState(next);
  return next;
}

export async function resetToSeedData(state) {
  const timestamp = nowIso();
  const seedIds = new Set(SEED_PLANTS.map((plant) => plant.id));
  const archivedCurrentPlants = state.plants
    .filter((plant) => !seedIds.has(plant.id))
    .map((plant) => normalizePlant({ ...plant, status: 'deleted', deletedAt: timestamp, updatedAt: timestamp }));
  const next = migrateGardenState({
    ...state,
    plants: SEED_PLANTS.map((plant) => normalizePlant({ ...plant, updatedAt: timestamp }, 'seed')),
    deletedPlants: [...archivedCurrentPlants, ...(state.deletedPlants || [])],
    zones: DEFAULT_ZONES.map(normalizeZone),
    careLogs: [],
    settings: { ...state.settings, seedVersion: SEED_VERSION, lastSeededAt: timestamp }
  });
  await persistFullState(next);
  return next;
}

export async function importGardenBackup(state, backup) {
  const timestamp = nowIso();
  const next = migrateGardenState({
    ...state,
    ...backup,
    settings: { ...state.settings, ...(backup.settings || {}), lastMigratedAt: timestamp },
    meta: { ...(backup.meta || {}), importedAt: timestamp }
  });
  await persistFullState(next);
  return next;
}
